<?php
/**
 * Category Controller
 * Kategória CRUD endpointok
 */

require_once __DIR__ . '/../models/CategoryModel.php';
require_once __DIR__ . '/../middlewares/AuthMiddleware.php';
require_once __DIR__ . '/../utils/Response.php';
require_once __DIR__ . '/../utils/Validator.php';

class CategoryController {
    
    private CategoryModel $categoryModel;
    
    public function __construct() {
        $this->categoryModel = new CategoryModel();
    }
    
    /**
     * GET /categories
     * Kategóriák listázása (PUBLIC)
     */
    public function index(): void {
        try {
            $categories = $this->categoryModel->getAllWithProductCount();
            
            Response::success(['categories' => $categories]);
            
        } catch (Exception $e) {
            Response::error($e->getMessage(), 500);
        }
    }
    
    /**
     * GET /categories/{id}
     * Kategória részletei (PUBLIC)
     */
    public function show(int $id): void {
        try {
            $category = $this->categoryModel->getCategoryWithParent($id);
            
            if (!$category) {
                Response::notFound('Kategória nem található');
            }
            
            Response::success($category);
            
        } catch (Exception $e) {
            Response::error($e->getMessage(), 500);
        }
    }
    
    /**
     * POST /categories
     * Új kategória (ADMIN)
     */
    public function create(): void {
        try {
            AuthMiddleware::requireAdmin();
            
            $data = Validator::getJsonInput();
            
            $errors = Validator::required($data, ['name']);
            if (!empty($errors)) {
                Response::validationError($errors);
            }
            
            $categoryData = [
                'name' => Validator::sanitizeString($data['name']),
                'parent_id' => !empty($data['parent_id']) ? (int)$data['parent_id'] : null,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];
            
            $categoryId = $this->categoryModel->create($categoryData);
            
            Response::success(
                ['id' => $categoryId],
                'Kategória sikeresen létrehozva',
                201
            );
            
        } catch (Exception $e) {
            Response::error($e->getMessage(), 400);
        }
    }
    
    /**
     * PUT /categories/{id}
     * Kategória módosítása (ADMIN)
     */
    public function update(int $id): void {
        try {
            AuthMiddleware::requireAdmin();
            
            $data = Validator::getJsonInput();
            
            $updateData = [];
            if (isset($data['name'])) {
                $updateData['name'] = Validator::sanitizeString($data['name']);
            }
            if (isset($data['parent_id'])) {
                $updateData['parent_id'] = !empty($data['parent_id']) ? (int)$data['parent_id'] : null;
            }
            $updateData['updated_at'] = date('Y-m-d H:i:s');
            
            $success = $this->categoryModel->update($id, $updateData);
            
            if (!$success) {
                Response::error('Kategória frissítése sikertelen', 500);
            }
            
            Response::success(null, 'Kategória sikeresen frissítve');
            
        } catch (Exception $e) {
            Response::error($e->getMessage(), 400);
        }
    }
    
    /**
     * DELETE /categories/{id}
     * Kategória törlése (ADMIN)
     */
    public function delete(int $id): void {
        try {
            AuthMiddleware::requireAdmin();
            
            // Check if has products
            if ($this->categoryModel->hasProducts($id)) {
                Response::error('A kategória nem törölhető, mert vannak hozzá tartozó termékek', 400);
            }
            
            $success = $this->categoryModel->delete($id);
            
            if (!$success) {
                Response::error('Kategória törlése sikertelen', 500);
            }
            
            Response::success(null, 'Kategória sikeresen törölve');
            
        } catch (Exception $e) {
            Response::error($e->getMessage(), 400);
        }
    }
}
