<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/includes/auth_jwt.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  exit('Hibás kérés.');
}

$email  = trim($_POST['email'] ?? '');
$jelszo = $_POST['jelszo'] ?? '';

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  exit('Érvénytelen e-mail cím.');
}
if (strlen($jelszo) < 6) {
  exit('A jelszó túl rövid.');
}

// Felhasználó lekérése
$stmt = $mysqli->prepare("SELECT id, jelszo, teljes_nev, szerepkor_id FROM felhasznalok WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user || !password_verify($jelszo, $user['jelszo'])) {
  exit('Hibás e-mail vagy jelszó.');
}

// Frissítsd az utolsó belépés idejét
$upd = $mysqli->prepare("UPDATE felhasznalok SET modositva = NOW() WHERE id = ?");
$upd->bind_param("i", $user['id']);
$upd->execute();

// ✅ Access token (15 perc)
$access = issue_access_token([
  'sub'   => (int)$user['id'],
  'email' => $email,
  'role'  => ($user['szerepkor_id'] == 1 ? 'admin' : 'user')
]);

// ✅ Refresh token (14 nap)
$refresh = random_token(48);
store_refresh_token($mysqli, (int)$user['id'], $refresh);
set_refresh_cookie($refresh);

// Opcionális: SSR támogatás (hogy PHP oldalak is lássák)
setcookie('access', $access, [
  'expires'  => time() + ACCESS_TTL,
  'path'     => COOKIE_PATH,
  'domain'   => COOKIE_DOMAIN ?: '',
  'secure'   => COOKIE_SECURE,
  'httponly' => false,
  'samesite' => COOKIE_SAMESITE
]);

// ✅ Ha admin, mehet az admin dashboardra
if ((int)$user['szerepkor_id'] === 1) {
  header("Location: /raktar_pro/admin/index.php");
  exit;
}

// ✅ Ha sima user, mehet a főoldalra
header("Location: /raktar_pro/index.php");
exit;
