<?php
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

if (session_status() !== PHP_SESSION_ACTIVE) session_start();

function now_ts(): int { return time(); }
function dt($ts){ return date('Y-m-d H:i:s',$ts); }

function issue_access_token(array $claims): string {
  $payload = array_merge([
    'iss' => JWT_ISS,
    'iat' => now_ts(),
    'exp' => now_ts() + ACCESS_TTL,
  ], $claims);
  return JWT::encode($payload, JWT_SECRET, 'HS256');
}

function random_token(int $len = 64): string {
  return rtrim(strtr(base64_encode(random_bytes($len)), '+/', '-_'), '=');
}

function set_refresh_cookie(string $token, int $ttl = REFRESH_TTL): void {
  // HTTP-only, Secure, SameSite
  $params = [
    'expires'  => now_ts() + $ttl,
    'path'     => COOKIE_PATH,
    'domain'   => COOKIE_DOMAIN ?: '',
    'secure'   => COOKIE_SECURE,
    'httponly' => true,
    'samesite' => COOKIE_SAMESITE
  ];
  setcookie(REFRESH_COOKIE, $token, $params);
}

function clear_refresh_cookie(): void {
  setcookie(REFRESH_COOKIE, '', [
    'expires'=> time()-3600,
    'path'=>COOKIE_PATH,'domain'=>COOKIE_DOMAIN ?: '',
    'secure'=>COOKIE_SECURE,'httponly'=>true,'samesite'=>COOKIE_SAMESITE
  ]);
}

function store_refresh_token(mysqli $db, int $user_id, string $token): void {
  $hash = hash('sha256', $token);
  $exp  = dt(now_ts() + REFRESH_TTL);
  $ua   = $_SERVER['HTTP_USER_AGENT'] ?? null;
  $ip   = $_SERVER['REMOTE_ADDR'] ?? null;

  $stmt = $db->prepare("INSERT INTO refresh_tokens (user_id, token_hash, expires_at, user_agent, ip) VALUES (?,?,?,?,?)");
  $stmt->bind_param('issss', $user_id, $hash, $exp, $ua, $ip);
  $stmt->execute();
}

function revoke_refresh_token(mysqli $db, string $token): void {
  $hash = hash('sha256', $token);
  $stmt = $db->prepare("UPDATE refresh_tokens SET revoked=1 WHERE token_hash=?");
  $stmt->bind_param('s',$hash);
  $stmt->execute();
}

function verify_access_token(?string $jwt) {
  if (!$jwt) return null;
  try {
    $decoded = JWT::decode($jwt, new Key(JWT_SECRET, 'HS256'));
    if (($decoded->iss ?? null) !== JWT_ISS) return null;
    return $decoded; // tartalmazza: sub(user_id), role, exp stb.
  } catch (Throwable $e) {
    return null;
  }
}

/**
 * Kinyeri az access tokent:
 *  - Authorization: Bearer <token>
 *  - vagy cookie 'access' (ha így használod SSR-hez)
 */
function read_access_token_from_request(): ?string {
  $hdrs = function_exists('getallheaders') ? getallheaders() : [];
  $auth = $hdrs['Authorization'] ?? ($_SERVER['HTTP_AUTHORIZATION'] ?? '');
  if (stripos($auth, 'Bearer ') === 0) {
    return trim(substr($auth, 7));
  }
  // opcionális: cookie alapú access token támogatás SSR oldalakhoz
  if (!empty($_COOKIE['access'])) return $_COOKIE['access'];
  return null;
}

/** Middleware a védett oldalakhoz (API és SSR is) */
function require_auth(mysqli $db, ?array $roles = null) {
  $token = read_access_token_from_request();
  $decoded = verify_access_token($token);
  if (!$decoded) {
    http_response_code(401); echo 'Unauthorized'; exit;
  }
  // opcionális role check
  if ($roles && !in_array(($decoded->role ?? 'user'), $roles, true)) {
    http_response_code(403); echo 'Forbidden'; exit;
  }
  // elérhetővé tesszük a bejelentkezett usert
  $GLOBALS['auth'] = (object)[
    'user_id' => (int)$decoded->sub,
    'role'    => (string)($decoded->role ?? 'user'),
    'email'   => (string)($decoded->email ?? ''),
  ];
  return $GLOBALS['auth'];
}
