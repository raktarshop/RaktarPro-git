<?php
// ==================================================
// Raktár Pro – includes/auth_jwt.php (JWT + Refresh)
// ==================================================

// Kötelező: Composer autoload + config (konstansok)
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../config.php';

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

// Biztonsági fallback, ha valamiért config nélkül hívnák
if (!defined('REFRESH_COOKIE'))  define('REFRESH_COOKIE', 'rp_refresh');
if (!defined('COOKIE_SECURE'))   define('COOKIE_SECURE', false);
if (!defined('COOKIE_SAMESITE')) define('COOKIE_SAMESITE', 'Lax');
if (!defined('COOKIE_DOMAIN'))   define('COOKIE_DOMAIN', '');
if (!defined('COOKIE_PATH'))     define('COOKIE_PATH', '/');

if (session_status() !== PHP_SESSION_ACTIVE) {
  session_start();
}

function now_ts(): int { return time(); }
function dt($ts){ return date('Y-m-d H:i:s',$ts); }

function issue_access_token(array $claims): string {
  $payload = array_merge([
    'iss' => JWT_ISS,
    'iat' => now_ts(),
    'exp' => now_ts() + ACCESS_TTL,
  ], $claims);
  return JWT::encode($payload, JWT_SECRET, 'HS256');
}

function random_token(int $len = 64): string {
  return rtrim(strtr(base64_encode(random_bytes($len)), '+/', '-_'), '=');
}

function set_refresh_cookie(string $token, int $ttl = REFRESH_TTL): void {
  setcookie(REFRESH_COOKIE, $token, [
    'expires'  => now_ts() + $ttl,
    'path'     => COOKIE_PATH,
    'domain'   => COOKIE_DOMAIN ?: '',
    'secure'   => COOKIE_SECURE,
    'httponly' => true,
    'samesite' => COOKIE_SAMESITE
  ]);
}

function clear_refresh_cookie(): void {
  setcookie(REFRESH_COOKIE, '', [
    'expires'=> time()-3600,
    'path'=>COOKIE_PATH,
    'domain'=>COOKIE_DOMAIN ?: '',
    'secure'=>COOKIE_SECURE,
    'httponly'=>true,
    'samesite'=>COOKIE_SAMESITE
  ]);
}

function store_refresh_token(mysqli $db, int $user_id, string $token): void {
  $hash = hash('sha256', $token);
  $exp  = dt(now_ts() + REFRESH_TTL);
  $ua   = $_SERVER['HTTP_USER_AGENT'] ?? null;
  $ip   = $_SERVER['REMOTE_ADDR'] ?? null;

  $db->query("
    CREATE TABLE IF NOT EXISTS refresh_tokens (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      token_hash CHAR(64) NOT NULL,
      expires_at DATETIME NOT NULL,
      revoked TINYINT(1) NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      user_agent VARCHAR(255) NULL,
      ip VARCHAR(45) NULL,
      UNIQUE KEY uq_token_hash (token_hash),
      KEY idx_user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  ");

  $stmt = $db->prepare('INSERT INTO refresh_tokens (user_id, token_hash, expires_at, user_agent, ip) VALUES (?,?,?,?,?)');
  $stmt->bind_param('issss', $user_id, $hash, $exp, $ua, $ip);
  $stmt->execute();
}

function revoke_refresh_token(mysqli $db, string $token): void {
  $hash = hash('sha256', $token);
  $stmt = $db->prepare('UPDATE refresh_tokens SET revoked=1 WHERE token_hash=?');
  $stmt->bind_param('s',$hash);
  $stmt->execute();
}

function verify_access_token(?string $jwt) {
  if (!$jwt) return null;
  try {
    $decoded = JWT::decode($jwt, new Key(JWT_SECRET, 'HS256'));
    if (($decoded->iss ?? null) !== JWT_ISS) return null;
    return $decoded;
  } catch (Throwable $e) {
    return null;
  }
}

function read_access_token_from_request(): ?string {
  $hdrs = function_exists('getallheaders') ? getallheaders() : [];
  $auth = $hdrs['Authorization'] ?? ($_SERVER['HTTP_AUTHORIZATION'] ?? '');
  if (stripos($auth, 'Bearer ') === 0) {
    return trim(substr($auth, 7));
  }
  if (!empty($_COOKIE['access'])) return $_COOKIE['access'];
  return null;
}

/**
 * Ha az access token hiányzik/lejárt/hibás,
 * de van érvényes refresh a DB-ben, ad egy újat és beállítja a cookie-t,
 * majd visszaadja a DEKÓDOLT új tokent.
 */
function try_refresh_and_issue(mysqli $db) {
  $refresh = $_COOKIE[REFRESH_COOKIE] ?? '';
  if (!$refresh) return null;

  $hash = hash('sha256', $refresh);
  $stmt = $db->prepare("SELECT user_id, expires_at, revoked FROM refresh_tokens WHERE token_hash=? LIMIT 1");
  $stmt->bind_param('s', $hash);
  $stmt->execute();
  $row = $stmt->get_result()->fetch_assoc();
  if (!$row) return null;
  if ((int)$row['revoked'] === 1) return null;
  if (strtotime($row['expires_at']) < now_ts()) return null;

  // Felhasználó lekérése claimsekhez
  $u_stmt = $db->prepare("SELECT id, email, szerepkor_id FROM felhasznalok WHERE id=? LIMIT 1");
  $u_stmt->bind_param('i', $row['user_id']);
  $u_stmt->execute();
  $u = $u_stmt->get_result()->fetch_assoc();
  if (!$u) return null;

  $access = issue_access_token([
    'sub'   => (int)$u['id'],
    'email' => $u['email'],
    'role'  => ((int)$u['szerepkor_id'] === 1 ? 'admin' : 'user'),
  ]);

  // új access cookie
  setcookie('access', $access, [
    'expires'  => time() + ACCESS_TTL,
    'path'     => COOKIE_PATH,
    'domain'   => COOKIE_DOMAIN ?: '',
    'secure'   => COOKIE_SECURE,
    'httponly' => false,
    'samesite' => COOKIE_SAMESITE,
  ]);

  // visszaadjuk a dekódolt új tokent azonnal
  return verify_access_token($access);
}

function require_auth(mysqli $db, ?array $roles = null) {
  // 1) access token
  $token = read_access_token_from_request();
  $decoded = verify_access_token($token);

  // 2) ha nincs/lejárt → próbáljuk refresh-sel
  if (!$decoded) {
    $decoded = try_refresh_and_issue($db);
  }

  // 3) ha még mindig semmi → login
  if (!$decoded) {
    header('Location: /raktar_pro/bejelentkezes.html?err=hibas');
    exit;
  }

  // 4) szerepkör ellenőrzés
  if ($roles && !in_array(($decoded->role ?? 'user'), $roles, true)) {
    http_response_code(403); echo 'Forbidden'; exit;
  }

  $GLOBALS['auth'] = (object)[
    'user_id' => (int)$decoded->sub,
    'role'    => (string)($decoded->role ?? 'user'),
    'email'   => (string)($decoded->email ?? ''),
  ];
  return $GLOBALS['auth'];
}
