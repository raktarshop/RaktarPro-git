<?php
require_once __DIR__.'/../config.php';
require_once __DIR__.'/../vendor/autoload.php';
require_once __DIR__.'/../includes/db.php';
require_once __DIR__.'/../includes/auth_jwt.php';

header('Content-Type: application/json; charset=utf-8');
require_auth($mysqli, ['admin','user']);

// ... logika, $auth->user_id használható
