<?php
require_once __DIR__.'/../config.php';
require_once __DIR__.'/../includes/db.php';
require_once __DIR__.'/../includes/auth_jwt.php';

$refresh = $_COOKIE[REFRESH_COOKIE] ?? '';
if ($refresh) revoke_refresh_token($mysqli, $refresh);

clear_refresh_cookie();
setcookie('access','',[
  'expires'=> time()-3600, 'path'=>COOKIE_PATH,
  'domain'=>COOKIE_DOMAIN ?: '', 'secure'=>COOKIE_SECURE, 'httponly'=>false, 'samesite'=>COOKIE_SAMESITE
]);

header('Location: /index.php');
exit;
