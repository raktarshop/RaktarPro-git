<?php
require_once __DIR__.'/../config.php';
require_once __DIR__.'/../vendor/autoload.php';
require_once __DIR__.'/../includes/db.php';        // $mysqli
require_once __DIR__.'/../includes/auth_jwt.php';

header('Content-Type: application/json; charset=utf-8');

$email = trim($_POST['email'] ?? '');
$pass  = (string)($_POST['password'] ?? '');

$stmt = $mysqli->prepare("SELECT id, email, password_hash, role FROM users WHERE email=? LIMIT 1");
$stmt->bind_param('s',$email);
$stmt->execute();
$u = $stmt->get_result()->fetch_assoc();

if (!$u || !password_verify($pass, $u['password_hash'])) {
  http_response_code(401);
  echo json_encode(['ok'=>false,'msg'=>'Hibás bejelentkezési adatok']);
  exit;
}

// Access token
$access = issue_access_token([
  'sub'   => (int)$u['id'],
  'email' => $u['email'],
  'role'  => $u['role'] ?? 'user',
]);

// Refresh token (random, DB-be hash kerül)
$refresh = random_token(48);
store_refresh_token($mysqli, (int)$u['id'], $refresh);
set_refresh_cookie($refresh);

// Opcionális: SSR segítéshez (nem HttpOnly) access cookie 15p-ig
setcookie('access', $access, [
  'expires'=> time()+ACCESS_TTL, 'path'=>COOKIE_PATH,
  'domain'=>COOKIE_DOMAIN ?: '', 'secure'=>COOKIE_SECURE, 'httponly'=>false, 'samesite'=>COOKIE_SAMESITE
]);

echo json_encode(['ok'=>true,'access_token'=>$access,'exp'=>time()+ACCESS_TTL]);
