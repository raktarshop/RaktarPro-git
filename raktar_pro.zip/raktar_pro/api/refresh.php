<?php
require_once __DIR__.'/../config.php';
require_once __DIR__.'/../vendor/autoload.php';
require_once __DIR__.'/../includes/db.php';
require_once __DIR__.'/../includes/auth_jwt.php';

header('Content-Type: application/json; charset=utf-8');

$refresh = $_COOKIE[REFRESH_COOKIE] ?? '';
if (!$refresh) { http_response_code(401); echo json_encode(['ok'=>false]); exit; }

$hash = hash('sha256',$refresh);
$stmt = $mysqli->prepare("SELECT user_id, expires_at, revoked FROM refresh_tokens WHERE token_hash=? LIMIT 1");
$stmt->bind_param('s',$hash);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();

if (!$row || $row['revoked'] || strtotime($row['expires_at']) <= time()) {
  http_response_code(401); echo json_encode(['ok'=>false,'msg'=>'Refresh érvénytelen']); exit;
}

// új access token
$user_id = (int)$row['user_id'];

$u = $mysqli->query("SELECT email, role FROM users WHERE id=".$user_id." LIMIT 1")->fetch_assoc();
$access = issue_access_token([
  'sub'=>$user_id, 'email'=>$u['email'] ?? '', 'role'=>$u['role'] ?? 'user'
]);

// frissítjük az access cookie-t SSR kényelméhez
setcookie('access', $access, [
  'expires'=> time()+ACCESS_TTL, 'path'=>COOKIE_PATH,
  'domain'=>COOKIE_DOMAIN ?: '', 'secure'=>COOKIE_SECURE, 'httponly'=>false, 'samesite'=>COOKIE_SAMESITE
]);

echo json_encode(['ok'=>true,'access_token'=>$access,'exp'=>time()+ACCESS_TTL]);
