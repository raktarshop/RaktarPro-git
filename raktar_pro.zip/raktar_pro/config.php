<?php
/**
 * Raktár Pro – config.php (MAMP + JWT konstansok)
 * - DB kapcsolat (MAMP)
 * - mysqli exception alapú
 * - UTF-8 + időzóna
 * - Biztonságos session setup
 * - JWT **konstansok** (segédfüggvények NEM itt vannak)
 */

declare(strict_types=1);

// ===============================
// 🔧 Alap beállítások (MAMP)
// ===============================
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = 'root';
$DB_NAME = 'webaruhaz';
$DB_PORT = 8889;
$DB_SOCK = '/Applications/MAMP/tmp/mysql/mysql.sock';

// ===============================
// 🧱 Adatbázis kapcsolat
// ===============================
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME, $DB_PORT);
} catch (Throwable $e) {
    $mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME, null, $DB_SOCK);
}
$mysqli->set_charset('utf8mb4');

// ===============================
// 🕒 Időzóna
// ===============================
date_default_timezone_set('Europe/Budapest');

// ===============================
// 🔒 Session (átmenetileg megtartva)
// ===============================
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'secure'   => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
        'samesite' => 'Lax',
    ]);
    session_start();
}

// ===============================
// 🔑 JWT KONSTANSOK (segédfüggvények az includes/auth_jwt.php-ben!)
// ===============================
const JWT_SECRET       = 'valtsd_meg_egy_hosszú_random_titokra_ami_titokban_marad';
const JWT_ISS          = 'raktarpro';
const ACCESS_TTL       = 900;      // 15 perc
const REFRESH_TTL      = 1209600;  // 14 nap

// Cookie beállítások (refresh tokenhez)
const REFRESH_COOKIE   = 'rp_refresh';
const COOKIE_SECURE    = false;    // HTTPS esetén true
const COOKIE_SAMESITE  = 'Lax';
const COOKIE_DOMAIN    = '';
const COOKIE_PATH      = '/';

// ===============================
// 🧩 Segédfüggvények (általános)
// ===============================

// HTML escapelés
if (!function_exists('h')) {
    function h(?string $s): string {
        return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
    }
}

// Session-alapú jogosultság (átmenetileg)
if (!function_exists('is_logged_in')) {
    function is_logged_in(): bool {
        return isset($_SESSION['user_id']) && (int)$_SESSION['user_id'] > 0;
    }
}
if (!function_exists('is_admin')) {
    function is_admin(): bool {
        return isset($_SESSION['szerepkor_id']) && (int)$_SESSION['szerepkor_id'] === 1;
    }
}

// CSRF segédek
if (!function_exists('csrf_token')) {
    function csrf_token(): string {
        if (empty($_SESSION['csrf'])) {
            $_SESSION['csrf'] = bin2hex(random_bytes(16));
        }
        return $_SESSION['csrf'];
    }
}
if (!function_exists('csrf_verify')) {
    function csrf_verify(?string $token): bool {
        return isset($_SESSION['csrf']) && is_string($token) && hash_equals($_SESSION['csrf'], $token);
    }
}
