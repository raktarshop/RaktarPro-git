<?php
/**
 * Raktár Pro – login.php (JWT + redirect / debug mód)
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/includes/auth_jwt.php';

// DEBUG: ha true, nem 302-vel irányítunk, hanem kiírunk mindent és 5 mp múlva lépünk tovább
const DEBUG_LOGIN = false;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /raktar_pro/bejelentkezes.html?err=hibas');
    exit;
}

// --- Bemenet ---
$email  = trim($_POST['email'] ?? '');
$jelszo = (string)($_POST['jelszo'] ?? '');

// --- Gyors validáció ---
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($jelszo) < 6) {
    header('Location: /raktar_pro/bejelentkezes.html?err=hibas');
    exit;
}

// --- E-mail normalizálás (kisbetű) és jelszó trim ---
$norm_email = strtolower($email);

// --- Felhasználó lekérése (case-insensitive e-mail), hash TRIM-elve (CHAR oszlop esetére) ---
$stmt = $mysqli->prepare("
    SELECT id, TRIM(jelszo) AS jelszo, teljes_nev, szerepkor_id, email
    FROM felhasznalok
    WHERE LOWER(email) = ?
    LIMIT 1
");
$stmt->bind_param('s', $norm_email);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// --- Jelszó ellenőrzés ---
if (!$user || !password_verify($jelszo, $user['jelszo'])) {
    header('Location: /raktar_pro/bejelentkezes.html?err=hibas');
    exit;
}

// --- Utolsó aktivitás frissítése (opcionális) ---
$upd = $mysqli->prepare('UPDATE felhasznalok SET modositva = NOW() WHERE id = ?');
$upd->bind_param('i', $user['id']);
$upd->execute();

// --- Access token (15p) ---
$access = issue_access_token([
    'sub'   => (int)$user['id'],
    'email' => $user['email'],
    'role'  => ((int)$user['szerepkor_id'] === 1 ? 'admin' : 'user'),
]);

// --- Refresh token (14 nap) ---
$refresh = random_token(48);
store_refresh_token($mysqli, (int)$user['id'], $refresh);
set_refresh_cookie($refresh);

// --- Access cookie (PHP oldalak is lássák) ---
setcookie('access', $access, [
  'expires'  => time() + ACCESS_TTL,
  'path'     => COOKIE_PATH,           // fontos: config.php-ben '/' legyen MAMP-hoz
  'domain'   => COOKIE_DOMAIN ?: '',
  'secure'   => COOKIE_SECURE,
  'httponly' => false,
  'samesite' => COOKIE_SAMESITE,
]);

// --- Céloldal szerepkör szerint ---
$target = ((int)$user['szerepkor_id'] === 1)
  ? '/raktar_pro/admin/index.php'
  : '/raktar_pro/index.php';

// ===== Normál működés: 302 redirect =====
if (!DEBUG_LOGIN) {
    header('Location: ' . $target);
    exit;
}

// ===== DEBUG mód: látható oldal + automatikus tovább =====
header_remove('Location');
header('Content-Type: text/plain; charset=utf-8');

echo "✅ LOGIN OK\n\n";
echo "Céloldal: {$target}\n\n";
echo "Set-Cookie fejlécek (amit a böngésző kapni fog):\n";
foreach (headers_list() as $h) {
  if (stripos($h, 'Set-Cookie:') === 0) {
    echo " - {$h}\n";
  }
}
echo "\nJelen kérés cookie-jai (itt még jellemzően nem látszik az új 'access'):\n";
echo " - access: " . ($_COOKIE['access'] ?? '[még nincs a requestben]') . "\n";
echo " - rp_refresh: " . ($_COOKIE[REFRESH_COOKIE] ?? '[még nincs a requestben]') . "\n";

echo "\n5 mp múlva automatikus továbbítás a céloldalra...";
header("Refresh:5; url={$target}");
exit;
