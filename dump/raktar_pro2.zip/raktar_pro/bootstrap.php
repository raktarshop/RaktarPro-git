<?php
// bootstrap.php
require_once __DIR__ . '/config.php';

// Állítsd a configban: define('APP_BASE', '/raktar_pro');
if (!defined('APP_BASE')) define('APP_BASE', '');

/* Session */
if (session_status() !== PHP_SESSION_ACTIVE) {
  session_set_cookie_params([
    'path'     => '/',      // vagy APP_BASE
    'httponly' => true,
    'samesite' => 'Lax',
    'secure'   => false     // MAMP-on http
  ]);
  session_start();
}

/* Helpers */
function h($s){ return htmlspecialchars($s ?? "", ENT_QUOTES, "UTF-8"); }

function login_url(): string {
  $candidates = ['/bejelentkezes.php','/bejelentkezes.html','/auth/bejelentkezes.php'];
  foreach ($candidates as $rel) {
    $full = rtrim($_SERVER['DOCUMENT_ROOT'],'/').APP_BASE.$rel;
    if (file_exists($full)) return APP_BASE.$rel;
  }
  return APP_BASE . '/index.php';
}

function url(string $path): string {
  // mindig "/"-sel kezdd a path-ot: pl. url('/rendeleseim.php')
  return APP_BASE . $path;
}

/* Auth guardok */
function require_login(): void {
  if (empty($_SESSION['user_id'])) {
    header('Location: ' . login_url() . '?m=reauth');
    exit;
  }
}

function require_admin(): void {
  require_login();
  $role = (int)($_SESSION['szerepkor_id'] ?? 3);
  if ($role !== 1) {
    http_response_code(403);
    echo 'Hozzáférés megtagadva (admin szükséges).';
    exit;
  }
}
