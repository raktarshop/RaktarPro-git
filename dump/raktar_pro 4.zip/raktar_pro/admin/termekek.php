<?php
require_once __DIR__ . '/_init.php';

// kis szűrő (keresés)
$q = trim($_GET['q'] ?? '');
$where = "WHERE 1=1";
$params = [];
$types = '';

if ($q !== '') {
  $where .= " AND (t.name LIKE CONCAT('%', ?, '%') OR t.sku LIKE CONCAT('%', ?, '%'))";
  $params = [$q, $q];
  $types = 'ss';
}

/**
 * VALÓS KÉSZLET:
 * available = SUM(stock.quantity - stock.reserved_quantity)
 * (0 alá ne menjen)
 */
$sql = "SELECT
          t.id,
          t.sku        AS cikkszam,
          t.name       AS nev,
          t.unit_price AS egysegar,
          t.image_url  AS kep_url,
          k.name       AS kategoria,
          GREATEST(COALESCE(SUM(s.quantity - s.reserved_quantity), 0), 0) AS keszlet
        FROM products t
        LEFT JOIN categories k ON k.id = t.category_id
        LEFT JOIN stock s ON s.product_id = t.id
        $where
        GROUP BY t.id, t.sku, t.name, t.unit_price, t.image_url, k.name
        ORDER BY t.id DESC
        LIMIT 200";

$stmt = $mysqli->prepare($sql);
if ($params) {
  $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <title>Admin – Termékek</title>
  <link rel="stylesheet" href="style_admin.css">
  <style>
    img.thumb {
      width: 60px;
      height: 60px;
      object-fit: cover;
      border-radius: 6px;
      border: 1px solid #ddd;
    }
    .badge {
      background: #f3f4f6;
      padding: 4px 8px;
      border-radius: 9999px;
      font-size: 0.9em;
      color: #374151;
      border: 1px solid #e5e7eb;
      display:inline-block;
    }
    .badge.ok { background:#ecfdf5; color:#065f46; border-color:#a7f3d0; }
    .badge.bad { background:#fee2e2; color:#991b1b; border-color:#fecaca; }
    .table td, .table th { vertical-align: middle; }
    .btn.danger { background:#dc2626; color:#fff; }
    .btn.danger:hover { background:#b91c1c; }
    .btn.small { padding:8px 10px; border-radius:10px; }
  </style>
</head>
<body>
<div class="container">
  <div class="card">
    <div class="row" style="justify-content:space-between;align-items:center;">
      <h1>📦 Termékek</h1>
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
        <a class="btn outline" href="/raktar_pro/admin/kategoriak.php">🏷️ Kategóriák</a>
        <a class="btn outline" href="/raktar_pro/admin/index.php">← Dashboard</a>
        <a class="btn outline" href="/raktar_pro/index.php">🏪 Bolt nézete</a>
        <span class="badge">Admin: <?php echo h($_SESSION['teljes_nev'] ?? ''); ?></span>
      </div>
    </div>

    <form method="get" class="row" style="margin:10px 0;gap:8px;">
      <input type="text" name="q" placeholder="Keresés név / cikkszám alapján" value="<?php echo h($q); ?>" style="flex:1;">
      <button class="btn">🔍 Keresés</button>
    </form>

    <table class="table">
      <thead>
        <tr>
          <th>#</th>
          <th>Kép</th>
          <th>Cikkszám</th>
          <th>Név</th>
          <th>Kategória</th>
          <th>Ár</th>
          <th>Elérhető készlet</th>
          <th>Műveletek</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $r): ?>
          <?php $k = (int)($r['keszlet'] ?? 0); ?>
          <tr>
            <td><?php echo (int)$r['id']; ?></td>
            <td>
              <?php if (!empty($r['kep_url'])): ?>
                <img class="thumb" src="<?php echo h($r['kep_url']); ?>" alt="">
              <?php else: ?>
                <span class="badge">nincs kép</span>
              <?php endif; ?>
            </td>
            <td><?php echo h($r['cikkszam'] ?? '-'); ?></td>
            <td><?php echo h($r['nev'] ?? '-'); ?></td>
            <td><?php echo h($r['kategoria'] ?? '-'); ?></td>
            <td><?php echo number_format((float)($r['egysegar'] ?? 0), 0, '', ' '); ?> Ft</td>
            <td>
              <?php if ($k <= 0): ?>
                <span class="badge bad">0 db (nincs)</span>
              <?php else: ?>
                <span class="badge ok"><?php echo $k; ?> db</span>
              <?php endif; ?>
            </td>
            <td class="row" style="gap:6px;flex-wrap:wrap;">
              <!-- ÚJ: admin megtekintés -->
              <a class="btn outline small" href="termek.php?id=<?php echo (int)$r['id']; ?>">🧾 Admin</a>

              <!-- ÚJ: készlet szerkesztés -->
              <a class="btn outline small" href="keszlet_szerkeszt.php?product_id=<?php echo (int)$r['id']; ?>">📦 Készlet</a>

              <!-- meglévők -->
              <a class="btn outline small" href="termek_szerkeszt.php?id=<?php echo (int)$r['id']; ?>">✏️ Szerk.</a>
              <a class="btn outline small" href="termek_kep.php?id=<?php echo (int)$r['id']; ?>">🖼️ Kép</a>
              <a class="btn outline small" href="/raktar_pro/termek.php?id=<?php echo (int)$r['id']; ?>" target="_blank">👁️ Bolt</a>
              <a class="btn danger small" href="termek_torles.php?id=<?php echo (int)$r['id']; ?>">🗑️ Törlés</a>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (empty($rows)): ?>
          <tr>
            <td colspan="8" style="text-align:center;color:#666;">Nincs találat.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
</body>
</html>
