<?php
/**
 * Raktár Pro – login.php
 * - users táblával (webaruhaz1.sql)
 * - bcrypt + legacy plaintext jelszó támogatás (első sikeres belépésnél újrahash-eli)
 * - JWT cookie + session kompatibilitás (régi oldalakhoz)
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/includes/auth_jwt.php';

// DEBUG: ha true, nem 302-vel irányítunk, hanem kiírunk mindent és 5 mp múlva lépünk tovább
const DEBUG_LOGIN = false;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . APP_BASE . '/bejelentkezes.html?err=hibas');
    exit;
}

$email  = trim($_POST['email'] ?? '');
$jelszo = (string)($_POST['jelszo'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($jelszo) < 3) {
    header('Location: ' . APP_BASE . '/bejelentkezes.html?err=hibas');
    exit;
}

$norm_email = strtolower($email);

$stmt = $mysqli->prepare(
    "SELECT id, email, password_hash, full_name, role_id FROM users WHERE LOWER(email) = ? LIMIT 1"
);
$stmt->bind_param('s', $norm_email);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

$ok = false;
if ($user) {
    $stored = trim((string)($user['password_hash'] ?? ''));

    // bcrypt / password_hash
    if (str_starts_with($stored, '$2y$') || str_starts_with($stored, '$2a$') || str_starts_with($stored, '$argon2')) {
        $ok = password_verify($jelszo, $stored);
    } else {
        // legacy (dumpban több helyen sima szöveg van)
        $ok = hash_equals($stored, $jelszo);
        // ha jó volt: rehash
        if ($ok) {
            $newHash = password_hash($jelszo, PASSWORD_BCRYPT);
            $u = $mysqli->prepare('UPDATE users SET password_hash=?, updated_at=NOW() WHERE id=?');
            $u->bind_param('si', $newHash, $user['id']);
            $u->execute();
            $u->close();
            $user['password_hash'] = $newHash;
        }
    }
}

if (!$ok) {
    header('Location: ' . APP_BASE . '/bejelentkezes.html?err=hibas');
    exit;
}

// session kompatibilitás
$_SESSION['user_id']      = (int)$user['id'];
$_SESSION['email']        = (string)$user['email'];
$_SESSION['teljes_nev']   = (string)($user['full_name'] ?? '');
$_SESSION['szerepkor_id'] = (int)($user['role_id'] ?? 3);

// Access token
$access = issue_access_token([
    'sub'   => (int)$user['id'],
    'email' => (string)$user['email'],
    'role'  => ((int)($user['role_id'] ?? 3) === 1 ? 'admin' : 'user'),
]);

// Refresh token
$refresh = random_token(48);
store_refresh_token($mysqli, (int)$user['id'], $refresh);
set_refresh_cookie($refresh);

// Access cookie (PHP oldalak is lássák)
setcookie('access', $access, [
  'expires'  => time() + ACCESS_TTL,
  'path'     => COOKIE_PATH,
  'domain'   => COOKIE_DOMAIN ?: '',
  'secure'   => COOKIE_SECURE,
  'httponly' => false,
  'samesite' => COOKIE_SAMESITE,
]);

$target = ((int)($user['role_id'] ?? 3) === 1)
  ? APP_BASE . '/admin/index.php'
  : APP_BASE . '/index.php';

if (!DEBUG_LOGIN) {
    header('Location: ' . $target);
    exit;
}

header_remove('Location');
header('Content-Type: text/plain; charset=utf-8');

echo "✅ LOGIN OK\n\n";
echo "Céloldal: {$target}\n\n";
echo "Set-Cookie fejlécek:\n";
foreach (headers_list() as $h) {
  if (stripos($h, 'Set-Cookie:') === 0) {
    echo " - {$h}\n";
  }
}

echo "\nSession:\n";
echo " - user_id: " . ($_SESSION['user_id'] ?? 'n/a') . "\n";
echo " - szerepkor_id: " . ($_SESSION['szerepkor_id'] ?? 'n/a') . "\n";

echo "\n5 mp múlva automatikus továbbítás...";
header("Refresh:5; url={$target}");
exit;
