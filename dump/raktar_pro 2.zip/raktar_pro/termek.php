<?php
require_once __DIR__ . '/config.php';

function h($s){ return htmlspecialchars($s ?? "", ENT_QUOTES, "UTF-8"); }
$id = intval($_GET['id'] ?? 0);
if ($id <= 0) { http_response_code(404); exit('Termék nem található.'); }

/**
 * Termék + kategória + VALÓS készlet (stockból számolva, reserved levonva)
 * available = SUM(quantity - reserved_quantity)
 */
$stmt = $mysqli->prepare("
  SELECT
    t.id,
    t.sku AS cikkszam,
    t.name AS nev,
    t.description AS leiras,
    t.unit_price AS egysegar,
    t.image_url AS kep_url,
    k.name AS kategoria,
    GREATEST(COALESCE(SUM(s.quantity - s.reserved_quantity), 0), 0) AS available
  FROM products t
  LEFT JOIN categories k ON k.id = t.category_id
  LEFT JOIN stock s ON s.product_id = t.id
  WHERE t.id = ?
  GROUP BY t.id, t.sku, t.name, t.description, t.unit_price, t.image_url, k.name
  LIMIT 1
");
$stmt->bind_param("i", $id);
$stmt->execute();
$termek = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$termek) { http_response_code(404); exit('Termék nem található.'); }

/**
 * Készlet lokációnként (ELÉRHETŐ: quantity - reserved_quantity)
 */
$keszletek = [];
try {
  $q = $mysqli->prepare("
    SELECT
      w.name AS raktar,
      l.code AS hely,
      GREATEST(s.quantity - s.reserved_quantity, 0) AS mennyiseg
    FROM stock s
    JOIN locations l ON l.id = s.location_id
    JOIN warehouses w ON w.id = l.warehouse_id
    WHERE s.product_id = ?
    ORDER BY w.name, l.code
  ");
  $q->bind_param("i", $id);
  $q->execute();
  $keszletek = $q->get_result()->fetch_all(MYSQLI_ASSOC);
  $q->close();
} catch (Throwable $e) {
  // ha nincs locations/warehouses modul, hagyjuk üresen
}

$available_total = (int)($termek['available'] ?? 0);
?>
<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?php echo h($termek['nev']); ?> – Raktár Pro</title>

  <!-- meglévő oldal stílus -->
  <link rel="stylesheet" href="style_home.css" />

  <!-- toast (ugyanaz, mint a főoldalon) -->
  <link rel="stylesheet" href="/raktar_pro/assets/css/toast.css" />

  <style>
    .wrap{width:min(1100px,94vw);margin:24px auto;display:grid;grid-template-columns:1fr 1.2fr;gap:24px}
    .card{background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:16px}
    .imgbox{background:#eef2ff;border-radius:12px;display:grid;place-items:center;aspect-ratio:1/1;overflow:hidden}
    .imgbox img{max-width:100%;max-height:100%;object-fit:contain}
    .title{font-size:26px;font-weight:900;margin:6px 0}
    .meta{color:#6b7280;margin:2px 0}
    .price{font-size:22px;font-weight:900;margin-top:8px}
    .btn{display:inline-flex;gap:8px;align-items:center;background:#111827;color:#fff;border:none;border-radius:12px;padding:12px 16px;font-weight:800;cursor:pointer}
    .btn.outline{background:#fff;color:#111827;border:1px solid #111827}
    .qty{display:inline-flex;align-items:center;border:1px solid #e5e7eb;border-radius:10px;overflow:hidden}
    .qty input{width:68px;padding:10px;border:0;outline:0;text-align:center}
    .table{width:100%;border-collapse:collapse;margin-top:10px}
    .table th,.table td{border-bottom:1px solid #e5e7eb;padding:8px;text-align:left}
    .crumbs{color:#6b7280;margin:8px 0}
    .badge{display:inline-block;padding:4px 8px;border-radius:9999px;border:1px solid #e5e7eb}

    /* loading állapot a gombon */
    .btn.loading{opacity:.75;pointer-events:none}
  </style>
</head>
<body>
  <!-- NAV -->
  <div class="nav">
    <div class="container row">
      <div class="brand">
        <div class="logo">RP</div>
        <div><div>Raktár Pro</div><small style="color:#6b7280">Termék</small></div>
      </div>
      <div class="right">
        <a class="btn outline" href="index.php">← Vissza</a>
        <a class="btn outline" href="/raktar_pro/kosar.php">🛒 Kosár</a>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="crumbs">
      Kategória: <?php echo h($termek['kategoria'] ?: 'N/A'); ?>
      • Cikkszám: <?php echo h($termek['cikkszam']); ?>
    </div>

    <div class="wrap">
      <div class="card">
        <div class="imgbox">
          <?php if (!empty($termek['kep_url'])): ?>
            <img src="<?php echo h($termek['kep_url']); ?>" alt="<?php echo h($termek['nev']); ?>">
          <?php else: ?>
            <div style="font-weight:900;color:#1f2937"><?php echo h($termek['cikkszam']); ?></div>
          <?php endif; ?>
        </div>
      </div>

      <div class="card">
        <div class="title"><?php echo h($termek['nev']); ?></div>
        <div class="meta"><?php echo h($termek['kategoria'] ?: ''); ?></div>
        <div class="meta"><?php echo nl2br(h($termek['leiras'] ?: '')); ?></div>

        <div class="price" style="display:flex;align-items:center;gap:10px">
          <?php echo number_format((float)$termek['egysegar'], 0, '', ' '); ?> Ft

          <?php if ($available_total <= 0): ?>
            <span class="badge" style="background:#fee2e2;color:#991b1b;border:1px solid #fecaca">Nincs készleten</span>
          <?php else: ?>
            <!-- NEM írunk ki darabszámot kötelezően, csak státuszt -->
            <span class="badge" style="background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0">Készleten</span>
          <?php endif; ?>
        </div>

        <!-- Kosárba -->
        <form method="post" action="/raktar_pro/add_to_cart.php" class="add-to-cart-form"
              style="margin-top:14px;display:flex;gap:10px;align-items:center">
          <?php if ($available_total > 0): ?>
            <div class="qty">
              <input type="number" name="qty" value="1" min="1" max="<?php echo (int)$available_total; ?>" />
            </div>
            <input type="hidden" name="termek_id" value="<?php echo (int)$termek['id']; ?>">
            <button class="btn" type="submit">🛒 Kosárba</button>
          <?php else: ?>
            <button class="btn" type="button" disabled style="opacity:.6;cursor:not-allowed">Nincs készleten</button>
          <?php endif; ?>
        </form>

        <?php if (!empty($keszletek)): ?>
          <?php
            // csak azokat mutassuk, ahol tényleg van elérhető
            $keszletek_szurt = array_values(array_filter($keszletek, fn($x) => (int)$x['mennyiseg'] > 0));
          ?>
          <?php if (!empty($keszletek_szurt)): ?>
            <div style="margin-top:18px">
              <div style="font-weight:800;margin-bottom:6px">Készlet elérhetőség</div>
              <table class="table">
                <thead><tr><th>Raktár</th><th>Hely</th><th>Mennyiség</th></tr></thead>
                <tbody>
                  <?php foreach ($keszletek_szurt as $k): ?>
                    <tr>
                      <td><?php echo h($k['raktar']); ?></td>
                      <td><?php echo h($k['hely']); ?></td>
                      <td><?php echo (int)$k['mennyiseg']; ?> db</td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        <?php endif; ?>

      </div>
    </div>
  </div>

  <!-- toast script -->
  <script src="/raktar_pro/assets/js/toast.js"></script>

  <!-- Kosárba rakás ugyanúgy, mint a főoldalon -->
  <script>
  document.querySelectorAll('.add-to-cart-form').forEach(form => {
    form.addEventListener('submit', async function(e) {
      e.preventDefault();

      const formData = new FormData(this);
      const btn = this.querySelector('button[type="submit"]');
      const original = btn ? btn.innerHTML : '';

      if (btn) { btn.disabled = true; btn.classList.add('loading'); }

      try {
        const res = await fetch('/raktar_pro/add_to_cart.php', {
          method: 'POST',
          body: formData,
          headers: {
            'Accept': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
          }
        });

        const data = await res.json().catch(() => null);

        if (!res.ok || !data || data.success !== true) {
          const msg = (data && (data.error || data.message)) ? (data.error || data.message) : 'Hiba történt';
          throw new Error(msg);
        }

        window.toast?.success?.('Termék hozzáadva a kosárhoz! 🛒');

        if (btn) {
          btn.innerHTML = '✓ Hozzáadva';
          setTimeout(() => {
            btn.innerHTML = original;
            btn.disabled = false;
          }, 1200);
        }

      } catch (err) {
        window.toast?.error?.(err.message || 'Hiba történt');
        if (btn) { btn.innerHTML = original; btn.disabled = false; }
      } finally {
        if (btn) btn.classList.remove('loading');
      }
    });
  });
  </script>
</body>
</html>
