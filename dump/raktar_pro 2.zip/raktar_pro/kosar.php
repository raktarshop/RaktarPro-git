<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/cart_utils.php';

function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

$items = cart_items($mysqli);
$total = cart_total($mysqli);

// --- VALÓS KÉSZLET lekérése a stock táblából (összes lokáció, reserved levonva) ---
$availability = []; // product_id => available

if (!empty($items)) {
  // készítsünk egy IN (?) listát biztonságosan
  $ids = array_values(array_unique(array_map(fn($it) => (int)$it['id'], $items)));
  $placeholders = implode(',', array_fill(0, count($ids), '?'));
  $types = str_repeat('i', count($ids));

  $sql = "
    SELECT
      p.id AS product_id,
      GREATEST(COALESCE(SUM(s.quantity - s.reserved_quantity), 0), 0) AS available
    FROM products p
    LEFT JOIN stock s ON s.product_id = p.id
    WHERE p.id IN ($placeholders)
    GROUP BY p.id
  ";

  $stmt = $mysqli->prepare($sql);
  if ($stmt) {
    $stmt->bind_param($types, ...$ids);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
      $availability[(int)$row['product_id']] = (int)$row['available'];
    }
    $stmt->close();
  } else {
    // ha valamiért nem sikerül, maradjon 0 (biztonság: checkout tiltás)
    foreach ($ids as $pid) $availability[(int)$pid] = 0;
  }
}

// --- Validáció: van-e olyan tétel, ami nem vehető meg? ---
$hasProblem = false;
$problems = []; // pid => msg

foreach ($items as $it) {
  $pid = (int)$it['id'];
  $qty = (int)$it['qty'];
  $avail = (int)($availability[$pid] ?? 0);

  if ($avail <= 0) {
    $hasProblem = true;
    $problems[$pid] = 'Jelenleg nincs készleten.';
  } elseif ($qty > $avail) {
    $hasProblem = true;
    $problems[$pid] = 'Nem elegendő készlet. Elérhető: ' . $avail . ' db.';
  }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <title>Kosár – Raktár Pro</title>

  <!-- SAJÁT CSS -->
  <link rel="stylesheet" href="/raktar_pro/assets/css/variables.css">
  <link rel="stylesheet" href="/raktar_pro/assets/css/base.css">
  <link rel="stylesheet" href="/raktar_pro/assets/css/components.css">
  <link rel="stylesheet" href="/raktar_pro/assets/css/layout.css">
  <link rel="stylesheet" href="/raktar_pro/assets/css/kosar.css">

  <style>
    .stock-note{
      margin-top:6px;
      font-size: 0.92rem;
      padding: 6px 10px;
      border-radius: 10px;
      display: inline-block;
      border: 1px solid #e5e7eb;
      background: #f9fafb;
      color: #111827;
    }
    .stock-note.bad{
      border-color:#fecaca;
      background:#fef2f2;
      color:#7f1d1d;
      font-weight: 700;
    }
    .stock-note.warn{
      border-color:#fde68a;
      background:#fffbeb;
      color:#92400e;
      font-weight: 700;
    }
    .cart-blocker{
      margin: 12px 0 0;
      padding: 10px 12px;
      border-radius: 12px;
      border: 1px solid #fecaca;
      background: #fef2f2;
      color: #7f1d1d;
      font-weight: 700;
    }
    .btn.disabled, .btn[aria-disabled="true"]{
      opacity: .55;
      pointer-events: none;
      cursor: not-allowed;
      filter: grayscale(20%);
    }
  </style>
</head>
<body>

<div class="cart-page">

  <h1>🛒 Kosár</h1>

  <?php if (empty($items)): ?>

    <!-- ÜRES KOSÁR -->
    <div class="cart-empty-box">
      <p>A kosarad jelenleg üres.</p>
      <a href="/raktar_pro/index.php" class="btn btn-primary">
        Vásárlás folytatása
      </a>
    </div>

  <?php else: ?>

    <?php if ($hasProblem): ?>
      <div class="cart-blocker">
        Van olyan termék a kosárban, ami jelenleg nem rendelhető. Kérlek távolítsd el, vagy csökkentsd a darabszámot.
      </div>
    <?php endif; ?>

    <!-- KOSÁR TÁBLA -->
    <table class="cart-table">
      <thead>
        <tr>
          <th>Termék</th>
          <th>Ár</th>
          <th>Db</th>
          <th>Összesen</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($items as $i): ?>
          <?php
            $pid = (int)$i['id'];
            $qty = (int)$i['qty'];
            $avail = (int)($availability[$pid] ?? 0);
            $problem = $problems[$pid] ?? '';
          ?>
          <tr>

            <!-- TERMÉK -->
            <td>
              <div class="cart-product">
                <?php if (!empty($i['kep_url'])): ?>
                  <img src="<?= h($i['kep_url']) ?>" alt="<?= h($i['nev']) ?>">
                <?php endif; ?>
                <span class="cart-product-name">
                  <?= h($i['nev']) ?>
                </span>
              </div>

              <?php if ($problem): ?>
                <!-- NEM MUTATUNK 0 DB-ot, csak státuszt -->
                <div class="stock-note bad">
                  <?= h($problem) ?>
                </div>
              <?php else: ?>
                <!-- Ha minden oké, nem muszáj készletet kiírni -->
                <div class="stock-note">
                  Készleten
                </div>
              <?php endif; ?>

            </td>

            <!-- ÁR -->
            <td class="cart-price">
              <?= number_format((int)$i['egysegar'], 0, ' ', ' ') ?> Ft
            </td>

            <!-- DB -->
            <td class="cart-qty">
              <?= $qty ?>
            </td>

            <!-- ÖSSZEG -->
            <td class="cart-subtotal">
              <?= number_format((int)$i['subtotal'], 0, ' ', ' ') ?> Ft
            </td>

            <!-- TÖRLÉS -->
            <td>
              <a
                href="/raktar_pro/cart_remove.php?id=<?= $pid ?>"
                class="cart-remove"
                title="Eltávolítás"
              >
                ❌
              </a>
            </td>

          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <!-- ÖSSZESÍTŐ -->
    <div class="cart-summary">
      <div class="cart-total">
        Összesen: <span><?= number_format((int)$total, 0, ' ', ' ') ?> Ft</span>
      </div>

      <div class="cart-actions">
        <a href="/raktar_pro/index.php" class="btn btn-outline">
          ← Vásárlás folytatása
        </a>

        <?php if ($hasProblem): ?>
          <a href="#" class="btn btn-primary disabled" aria-disabled="true" title="Van nem rendelhető termék a kosárban">
            Tovább a fizetéshez →
          </a>
        <?php else: ?>
          <a href="/raktar_pro/checkout.php" class="btn btn-primary">
            Tovább a fizetéshez →
          </a>
        <?php endif; ?>
      </div>
    </div>

  <?php endif; ?>

</div>

</body>
</html>
