/**
 * Raktár Pro - Toast Notification System
 * Használat: window.toast.success('Sikeres művelet!')
 */

class Toast {
  constructor() {
    this.container = null;
    this.toasts = new Map();
    this.init();
  }

  init() {
    // Toast container létrehozása
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.className = 'toast-container';
      this.container.setAttribute('aria-live', 'polite');
      this.container.setAttribute('aria-atomic', 'true');
      document.body.appendChild(this.container);
    }
  }

  /**
   * Toast megjelenítése
   * @param {string} message - Üzenet szövege
   * @param {string} type - Típus: success, error, warning, info
   * @param {number} duration - Megjelenítési idő ms-ban (0 = végtelen)
   * @returns {string} Toast ID
   */
  show(message, type = 'info', duration = 3000) {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const toast = document.createElement('div');
    toast.className = `toast toast--${type}`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('id', id);
    
    const icon = this.getIcon(type);
    
    toast.innerHTML = `
      <div class="toast__icon">${icon}</div>
      <div class="toast__content">
        <div class="toast__message">${this.escapeHtml(message)}</div>
      </div>
      <button class="toast__close" aria-label="Bezárás" type="button">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    `;
    
    // Bezárás gomb esemény
    const closeBtn = toast.querySelector('.toast__close');
    closeBtn.addEventListener('click', () => this.hide(id));
    
    // Hozzáadás a containerhez
    this.container.appendChild(toast);
    this.toasts.set(id, toast);
    
    // Animáció indítása
    requestAnimationFrame(() => {
      toast.classList.add('toast--show');
    });
    
    // Automatikus bezárás
    if (duration > 0) {
      setTimeout(() => this.hide(id), duration);
    }
    
    return id;
  }

  /**
   * Toast elrejtése
   * @param {string} id - Toast ID
   */
  hide(id) {
    const toast = this.toasts.get(id);
    if (!toast) return;
    
    toast.classList.remove('toast--show');
    toast.classList.add('toast--hide');
    
    // Animáció után eltávolítás
    setTimeout(() => {
      if (toast.parentNode) {
        toast.parentNode.removeChild(toast);
      }
      this.toasts.delete(id);
    }, 300);
  }

  /**
   * Összes toast bezárása
   */
  hideAll() {
    this.toasts.forEach((toast, id) => this.hide(id));
  }

  /**
   * Shorthand metódusok
   */
  success(message, duration = 3000) {
    return this.show(message, 'success', duration);
  }

  error(message, duration = 4000) {
    return this.show(message, 'error', duration);
  }

  warning(message, duration = 3500) {
    return this.show(message, 'warning', duration);
  }

  info(message, duration = 3000) {
    return this.show(message, 'info', duration);
  }

  /**
   * Töltési toast (végtelen, manuálisan kell bezárni)
   */
  loading(message = 'Betöltés...') {
    return this.show(message, 'loading', 0);
  }

  /**
   * Promise toast (automatikusan vált sikeres/hiba státuszra)
   * @param {Promise} promise
   * @param {Object} messages - { loading, success, error }
   */
  async promise(promise, messages = {}) {
    const loadingId = this.loading(messages.loading || 'Betöltés...');
    
    try {
      const result = await promise;
      this.hide(loadingId);
      this.success(messages.success || 'Sikeres művelet!');
      return result;
    } catch (error) {
      this.hide(loadingId);
      this.error(messages.error || 'Hiba történt!');
      throw error;
    }
  }

  /**
   * Icon lekérése típus szerint
   */
  getIcon(type) {
    const icons = {
      success: `<svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <polyline points="20 6 9 17 4 12"></polyline>
      </svg>`,
      error: `<svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="15" y1="9" x2="9" y2="15"></line>
        <line x1="9" y1="9" x2="15" y2="15"></line>
      </svg>`,
      warning: `<svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
        <line x1="12" y1="9" x2="12" y2="13"></line>
        <line x1="12" y1="17" x2="12.01" y2="17"></line>
      </svg>`,
      info: `<svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="12" y1="16" x2="12" y2="12"></line>
        <line x1="12" y1="8" x2="12.01" y2="8"></line>
      </svg>`,
      loading: `<svg class="toast__spinner" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <line x1="12" y1="2" x2="12" y2="6"></line>
        <line x1="12" y1="18" x2="12" y2="22"></line>
        <line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line>
        <line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line>
        <line x1="2" y1="12" x2="6" y2="12"></line>
        <line x1="18" y1="12" x2="22" y2="12"></line>
        <line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line>
        <line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line>
      </svg>`
    };
    
    return icons[type] || icons.info;
  }

  /**
   * HTML escape (XSS védelem)
   */
  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}

// Globális példány létrehozása
if (typeof window !== 'undefined') {
  window.toast = new Toast();
  
  // Keyboard támogatás (Escape bezárja az összeset)
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      window.toast.hideAll();
    }
  });
}

// Export (ha module használat)
if (typeof module !== 'undefined' && module.exports) {
  module.exports = Toast;
}