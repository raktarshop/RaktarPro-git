<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/cart_utils.php';

$q    = trim($_GET['q'] ?? '');
$kat  = intval($_GET['kat'] ?? 0);
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 12;
$offset = ($page - 1) * $limit;

// Kategóriák
$kats = [];
if ($res = $mysqli->query("SELECT id, name AS nev FROM categories ORDER BY nev")) {
  while ($row = $res->fetch_assoc()) $kats[] = $row;
  $res->free();
}

// Szűrés
$where = "WHERE 1=1";
$params = [];
$types = '';

if ($q !== '') {
  $where .= " AND (t.name LIKE CONCAT('%', ?, '%')
               OR t.description LIKE CONCAT('%', ?, '%')
               OR t.sku LIKE CONCAT('%', ?, '%'))";
  $params = [$q, $q, $q];
  $types = 'sss';
}

if ($kat > 0) {
  $where .= " AND t.category_id = ?";
  $params[] = $kat;
  $types .= 'i';
}

/**
 * Találatok száma – csak készletesek számolása
 * (a készletet stockból számoljuk: SUM(quantity - reserved_quantity))
 */
$countSql = "
  SELECT COUNT(*) AS c FROM (
    SELECT t.id
    FROM products t
    LEFT JOIN stock s ON s.product_id = t.id
    $where
    GROUP BY t.id
    HAVING GREATEST(COALESCE(SUM(s.quantity - s.reserved_quantity), 0), 0) > 0
  ) x
";

$stmt = $mysqli->prepare($countSql);
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
$stmt->close();

/**
 * Termékek – készlet STOCK táblából számolva (reserved levonva)
 * + csak készletes termékeket mutatunk: HAVING available > 0
 */
$query = "
  SELECT
    t.id,
    t.sku          AS cikkszam,
    t.name         AS nev,
    t.description  AS leiras,
    t.unit_price   AS egysegar,
    t.image_url    AS kep_url,
    k.name         AS kategoria,
    GREATEST(COALESCE(SUM(s.quantity - s.reserved_quantity), 0), 0) AS available
  FROM products t
  LEFT JOIN categories k ON k.id = t.category_id
  LEFT JOIN stock s ON s.product_id = t.id
  $where
  GROUP BY
    t.id, t.sku, t.name, t.description, t.unit_price, t.image_url, k.name
  HAVING available > 0
  ORDER BY t.id DESC
  LIMIT ? OFFSET ?
";

if ($params) {
  $stmt = $mysqli->prepare($query);
  $stmt->bind_param($types . 'ii', ...array_merge($params, [$limit, $offset]));
} else {
  $stmt = $mysqli->prepare($query);
  $stmt->bind_param('ii', $limit, $offset);
}

$stmt->execute();
$products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$pages = max(1, (int)ceil($total / $limit));
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
$cartCount = function_exists('cart_count') ? cart_count() : 0;
?>

<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Raktár Pro – Főoldal | Professzionális raktári megoldások</title>
  <meta name="description" content="Raktár Pro - 1000+ termék raktáron. Ipari eszközök, irodai kellékek, gyors szállítás.">
  
  <!-- CSS -->
  <link rel="stylesheet" href="/raktar_pro/assets/css/variables.css">
  <link rel="stylesheet" href="/raktar_pro/assets/css/base.css">
  <link rel="stylesheet" href="/raktar_pro/assets/css/components.css">
  <link rel="stylesheet" href="/raktar_pro/assets/css/layout.css">
  <link rel="stylesheet" href="/raktar_pro/assets/css/toast.css">
  <link rel="stylesheet" href="/raktar_pro/assets/cart-fab.css">
  
  <style>
    /* Product Card stílusok */
    .product-card {
      background: var(--color-card);
      border: 1px solid var(--color-border);
      border-radius: var(--radius-lg);
      overflow: hidden;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      display: flex;
      flex-direction: column;
    }

    .product-card:hover {
      transform: translateY(-4px);
      box-shadow: var(--shadow-xl);
    }

    .product-card__image-wrapper {
      position: relative;
      height: 200px;
      background: var(--color-border-light);
      overflow: hidden;
    }

    .product-card__image {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.5s ease;
    }

    .product-card:hover .product-card__image {
      transform: scale(1.05);
    }

    .product-card__placeholder {
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--color-muted);
      font-weight: var(--font-weight-semibold);
    }

    .product-card__body {
      padding: var(--space-lg);
      display: flex;
      flex-direction: column;
      gap: var(--space-sm);
      flex: 1;
    }

    .product-card__category {
      font-size: var(--font-size-xs);
      color: var(--color-muted);
      text-transform: uppercase;
      letter-spacing: 0.05em;
      font-weight: var(--font-weight-semibold);
    }

    .product-card__title {
      font-size: var(--font-size-lg);
      font-weight: var(--font-weight-bold);
      color: var(--color-text);
      line-height: var(--line-height-tight);
      margin: 0;
    }

    .product-card__description {
      font-size: var(--font-size-sm);
      color: var(--color-text-light);
      line-height: var(--line-height-normal);
      flex: 1;
    }

    .product-card__footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: var(--space-md);
      margin-top: var(--space-md);
    }

    .product-card__price {
      display: flex;
      align-items: center;
      gap: var(--space-sm);
    }

    .product-card__price strong {
      font-size: var(--font-size-xl);
      font-weight: var(--font-weight-extrabold);
      color: var(--color-text);
    }

    .product-card__actions {
      display: flex;
      gap: var(--space-sm);
      margin-top: var(--space-md);
    }
  </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="container navbar__container">
    <!-- Brand -->
    <a href="/raktar_pro/index.php" class="navbar__brand">
      <div class="navbar__logo">RP</div>
      <div class="navbar__title">
        <span>Raktár Pro</span>
        <small>Professzionális raktári megoldások</small>
      </div>
    </a>

    <!-- Actions -->
    <div class="navbar__actions">
      <!-- Theme toggle -->
      <button id="themeToggle" class="navbar__icon-btn" aria-label="Téma váltása">
        🌙
      </button>

      <!-- Admin link (ha admin) -->
      <?php if (isset($_SESSION['szerepkor_id']) && (int)$_SESSION['szerepkor_id'] === 1): ?>
        <a href="/raktar_pro/admin/index.php" class="btn btn-sm">
          🛠️ Admin
        </a>
      <?php endif; ?>

      <!-- Kosár -->
      <a href="/raktar_pro/kosar.php" class="navbar__cart">
        🛒
        <?php if ($cartCount > 0): ?>
          <span class="badge badge-danger"><?= $cartCount ?></span>
        <?php endif; ?>
      </a>

      <!-- Profil -->
      <a href="/raktar_pro/profil.php" class="navbar__avatar" title="<?= h($_SESSION['teljes_nev'] ?? 'Profil') ?>">
        <?= strtoupper(substr($_SESSION['teljes_nev'] ?? 'U', 0, 1)) ?>
      </a>
    </div>
  </div>
</nav>

<!-- HERO -->
<section class="hero">
  <div class="hero__container container">
    <h1>Profi raktári megoldások</h1>
    <p>
      Fedezze fel széleskörű termékpalettánkat az ipari eszközöktől az irodai kellékekig.<br>
      Több mint <strong>1000+</strong> termék raktáron, gyors szállítással.
    </p>
    <div class="hero__perks">
      <span class="hero__perk">⚙️ Legmagasabb minőség</span>
      <span class="hero__perk">⭐ Megbízható szolgáltatás</span>
      <span class="hero__perk">⚡ Azonnali raktári készlet</span>
    </div>
  </div>
</section>

<div class="container">
  <!-- Keresés és szűrés -->
  <div class="search-card">
    <div class="search-card__title">🔎 Termékkeresés és szűrés</div>
    <form class="search-card__form" method="get" action="index.php">
      <div class="search-card__input-wrapper">
        <span>🔍</span>
        <input type="search" name="q" value="<?= h($q) ?>" placeholder="Terméknév, leírás vagy cikkszám...">
      </div>
      <div class="search-card__input-wrapper">
        <span>🧭</span>
        <select name="kat">
          <option value="0">Minden kategória</option>
          <?php foreach($kats as $row): ?>
            <option value="<?= (int)$row['id'] ?>" <?= $kat==$row['id'] ? 'selected' : '' ?>>
              <?= h($row['nev']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <button class="btn btn-primary" type="submit">Szűrés</button>
    </form>
    <div class="search-card__result-count"><?= (int)$total ?> termék találat</div>
  </div>

  <!-- Termékkártyák -->
  <div class="grid">
    <?php foreach($products as $p): ?>
      <article class="product-card">
        <div class="product-card__image-wrapper">
          <?php if (!empty($p['kep_url'])): ?>
            <img src="<?= h($p['kep_url']) ?>" alt="<?= h($p['nev']) ?>" class="product-card__image" loading="lazy">
          <?php else: ?>
            <div class="product-card__placeholder">Nincs kép</div>
          <?php endif; ?>
        </div>

        <div class="product-card__body">
          <span class="product-card__category"><?= h($p['kategoria'] ?? 'Egyéb') ?></span>
          <h3 class="product-card__title"><?= h($p['nev']) ?></h3>
          <p class="product-card__description"><?= h(mb_substr($p['leiras'] ?? '', 0, 80)) ?></p>

          <div class="product-card__footer">
            <div class="product-card__price">
              <strong><?= number_format((float)$p['egysegar'], 0, '', ' ') ?> Ft</strong>
              <span class="badge badge-success">Készleten</span>
            </div>
          </div>

          <div class="product-card__actions">
            <a href="/raktar_pro/termek.php?id=<?= (int)$p['id'] ?>" class="btn btn-outline btn-sm">
              Részletek
            </a>

            <form method="post" action="/raktar_pro/add_to_cart.php" class="add-to-cart-form">
              <input type="hidden" name="termek_id" value="<?= (int)$p['id'] ?>">
              <input type="hidden" name="qty" value="1">
              <button class="btn btn-primary btn-sm" type="submit">
                🛒 Kosárba
              </button>
            </form>
          </div>
        </div>
      </article>
    <?php endforeach; ?>

    <?php if(empty($products)): ?>
      <p style="grid-column:1/-1;text-align:center;color:var(--color-muted);">
        Nincs találat a megadott feltételekre.
      </p>
    <?php endif; ?>
  </div>

  <!-- Lapozás -->
  <?php if($pages > 1): ?>
    <div class="pager">
      <?php for($i=1; $i<=$pages; $i++):
        $qs = http_build_query(['q'=>$q, 'kat'=>$kat, 'page'=>$i]);
      ?>
        <a class="<?= $i==$page ? 'active' : '' ?>" href="index.php?<?= $qs ?>">
          <?= $i ?>
        </a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
</div>

<!-- Floating Cart FAB -->
<button id="cartFab" class="cart-fab" aria-label="Kosár megnyitása" aria-expanded="false">
  🛒 <span class="cart-badge" id="cartCount">0</span>
</button>

<div id="cartPopup" class="cart-popup" aria-hidden="true" role="dialog" aria-label="Kosár">
  <div class="cart-popup__header">
    <strong>Kosár</strong>
    <button id="cartClose" class="cart-close">✖</button>
  </div>
  <div id="cartItems" class="cart-popup__body">
    <div class="cart-empty">A kosarad üres.</div>
  </div>
  <div class="cart-popup__footer">
    <div class="cart-total">
      <span>Összesen:</span>
      <strong id="cartTotal">0 Ft</strong>
    </div>
    <a class="btn btn-primary" href="/raktar_pro/kosar.php">Ugrás a kosárhoz</a>
  </div>
</div>

<!-- Scripts -->
<script src="/raktar_pro/assets/theme.js"></script>
<script src="/raktar_pro/assets/js/toast.js"></script>
<script src="/raktar_pro/assets/cart-fab.js"></script>

<script>
// Kosárba tétel feedback (stabil: JSON parse + always reset)
document.querySelectorAll('.add-to-cart-form').forEach(form => {
  form.addEventListener('submit', async function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    const button = this.querySelector('button');
    const originalText = button.innerHTML;

    // Loading state
    button.disabled = true;
    button.classList.add('loading');

    try {
      const response = await fetch('/raktar_pro/add_to_cart.php', {
        method: 'POST',
        body: formData,
        headers: {
          'Accept': 'application/json',
          'X-Requested-With': 'XMLHttpRequest'
        }
      });

      const data = await response.json().catch(() => null);

      if (!response.ok || !data || data.success !== true) {
        const msg = (data && (data.error || data.message)) ? (data.error || data.message) : 'Hiba történt';
        throw new Error(msg);
      }

      window.toast?.success?.('Termék hozzáadva a kosárhoz! 🛒');

      window.dispatchEvent(new CustomEvent('cart:add', { detail: data.cart || null }));

      const badge = document.querySelector('.navbar__cart .badge');
      if (badge && data.cart && typeof data.cart.count === 'number') {
        badge.textContent = data.cart.count;
        badge.style.display = data.cart.count > 0 ? 'inline-flex' : 'none';
      }

      button.innerHTML = '✓ Hozzáadva';

      setTimeout(() => {
        button.innerHTML = originalText;
        button.disabled = false;
      }, 1200);

    } catch (error) {
      window.toast?.error?.(error.message || 'Hiba történt a kosárba helyezéskor');
      button.innerHTML = originalText;
      button.disabled = false;

    } finally {
      button.classList.remove('loading');
    }
  });
});

// Navbar scroll effect
let lastScroll = 0;
const navbar = document.querySelector('.navbar');

window.addEventListener('scroll', () => {
  const currentScroll = window.pageYOffset;

  if (currentScroll > 50) navbar.classList.add('scrolled');
  else navbar.classList.remove('scrolled');

  lastScroll = currentScroll;
});
</script>

</body>
</html>
