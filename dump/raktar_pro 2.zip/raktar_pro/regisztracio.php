<?php
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  exit('Hibás kérés.');
}

$email      = trim($_POST['email'] ?? '');
$jelszo     = (string)($_POST['jelszo'] ?? '');
$teljes_nev = trim($_POST['teljes_nev'] ?? '');
$cegnev     = trim($_POST['cegnev'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { exit('Érvénytelen e-mail cím.'); }
if (strlen($jelszo) < 6) { exit('A jelszó legalább 6 karakteres legyen.'); }
if ($teljes_nev === '') { exit('A teljes név kötelező.'); }

$email = strtolower($email);
$hash  = password_hash($jelszo, PASSWORD_DEFAULT);

// E-mail egyediség
$stmt = $mysqli->prepare("SELECT id FROM users WHERE LOWER(email)=? LIMIT 1");
$stmt->bind_param('s', $email);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) { exit('Ezzel az e-mail címmel már regisztráltak.'); }
$stmt->close();

// role_id: 3 = "user" (a webaruhaz1.sql roles táblája szerint)
$role_id = 3;
$stmt = $mysqli->prepare("INSERT INTO users (email, password_hash, full_name, company_name, role_id, created_at) VALUES (?,?,?,?,?, NOW())");
$stmt->bind_param('ssssi', $email, $hash, $teljes_nev, $cegnev, $role_id);

if ($stmt->execute()) {
  $uid = (int)$stmt->insert_id;

  // Session kompatibilitás
  $_SESSION['user_id']      = $uid;
  $_SESSION['email']        = $email;
  $_SESSION['teljes_nev']   = $teljes_nev;
  $_SESSION['szerepkor_id'] = $role_id;

  header('Location: dashboard.php');
  exit;
}

exit('Hiba történt a regisztrációnál: ' . $stmt->error);
