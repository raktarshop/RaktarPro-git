<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/cart_utils.php';

function h($s){ return htmlspecialchars($s ?? "", ENT_QUOTES, "UTF-8"); }

$items = cart_items($mysqli);
if (!$items) { header("Location: kosar.php"); exit; }

// CSRF
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
$csrf = $_SESSION['csrf'];

$pref_nev   = $_SESSION['teljes_nev'] ?? '';
$pref_email = $_SESSION['email'] ?? '';
$pref_cim   = '';

$msg = $err = '';
$total = cart_total($mysqli);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!hash_equals($csrf, $_POST['csrf'] ?? '')) {
    $err = "Érvénytelen kérés (CSRF).";
  } else {
    $nev   = trim($_POST['nev'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $cim   = trim($_POST['cim'] ?? '');
    $fiz   = ($_POST['fizetes_mod'] ?? 'utanvet');

    if ($nev   === '') $nev   = trim($_SESSION['teljes_nev'] ?? '');
    if ($email === '') $email = trim($_SESSION['email'] ?? '');
    if ($nev   === '') $nev   = 'Vásárló';
    if ($email === '') $email = 'nincs@pelda.hu';

    $nev   = mb_substr($nev,   0, 120);
    $email = mb_substr($email, 0, 120);
    $cim   = mb_substr($cim,   0, 255);
    $fiz   = mb_substr($fiz,   0, 50);

    if ($nev === '' || $email === '' || $cim === '') {
      $err = "Minden mező kötelező (név, e-mail, cím).";
    }
    if (!$err && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $err = "Érvénytelen e-mail cím.";
    }

    $items = cart_items($mysqli);
    $total = cart_total($mysqli);
    if (!$items) $err = "A kosár üres.";

    if ($err) { $pref_nev = $nev; $pref_email = $email; $pref_cim = $cim; }

    if (!$err) {
      $uid = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;

      try {
        $mysqli->begin_transaction();

        // 1) VALÓS KÉSZLETELLENŐRZÉS (stock tábla alapján)
        $need = []; // pid => qty

        $getAvail = $mysqli->prepare("
          SELECT
            p.name AS nev,
            GREATEST(COALESCE(SUM(s.quantity - s.reserved_quantity), 0), 0) AS available
          FROM products p
          LEFT JOIN stock s ON s.product_id = p.id
          WHERE p.id = ?
          GROUP BY p.id, p.name
          LIMIT 1
        ");

        foreach ($items as $it) {
          $pid = (int)$it['id'];
          $qty = (int)$it['qty'];

          $getAvail->bind_param("i", $pid);
          $getAvail->execute();
          $rs = $getAvail->get_result()->fetch_assoc();

          if (!$rs) {
            throw new Exception("Ismeretlen termék (ID: {$pid}).");
          }

          $name = $rs['nev'] ?? 'ismeretlen termék';
          $available = (int)($rs['available'] ?? 0);

          // Ha nincs készleten, NE írjunk “0 db”-ot
          if ($available <= 0) {
            throw new Exception("A(z) „".h($name)."” jelenleg nincs készleten.");
          }

          if ($qty > $available) {
            throw new Exception("A(z) „".h($name)."” készlete nem elegendő. Elérhető: {$available} db, kért: {$qty} db.");
          }

          $need[$pid] = $qty;
        }
        $getAvail->close();

        // 2) Rendelés fej (orders)
        $sql = "INSERT INTO orders (name, email, address, payment_method, gross_total, status, created_at, user_id)
                VALUES (?, ?, ?, ?, ?, 'uj', NOW(), ?)";
        $ins = $mysqli->prepare($sql);
        $gross_total = (int)$total;
        $ins->bind_param("ssssii", $nev, $email, $cim, $fiz, $gross_total, $uid);
        $ins->execute();
        $order_id = (int)$ins->insert_id;
        $ins->close();

        // 3) Tételek (app_order_items FK -> orders)
        $ins2 = $mysqli->prepare(
          "INSERT INTO app_order_items (order_id, product_id, quantity, unit_price, total_amount)
           VALUES (?, ?, ?, ?, ?)"
        );
        foreach ($items as $it) {
          $pid   = (int)$it['id'];
          $qty   = (int)$it['qty'];
          $price = (int)round((float)$it['egysegar']);
          $sum   = $price * $qty;
          $ins2->bind_param("iiiii", $order_id, $pid, $qty, $price, $sum);
          $ins2->execute();
        }
        $ins2->close();

        // 4) Készlet levonás a STOCK táblából (lokációkon végigmenve)
        // Megjegyzés: reserved_quantity-t nem növeljük itt; egyszerűen levonjuk a quantity-ból.
        $selRows = $mysqli->prepare("
          SELECT id, quantity, reserved_quantity
          FROM stock
          WHERE product_id = ?
          ORDER BY location_id ASC, id ASC
          FOR UPDATE
        ");

        $updRow = $mysqli->prepare("
          UPDATE stock
          SET quantity = ?, updated_at = NOW()
          WHERE id = ?
        ");

        foreach ($need as $pid => $qtyNeed) {
          $remaining = (int)$qtyNeed;

          $selRows->bind_param("i", $pid);
          $selRows->execute();
          $rows = $selRows->get_result()->fetch_all(MYSQLI_ASSOC);

          if (!$rows) {
            // Elvileg idáig nem jut, mert az available check megfogja,
            // de legyen biztos.
            throw new Exception("A termék készlete nem található (ID: {$pid}).");
          }

          foreach ($rows as $r) {
            if ($remaining <= 0) break;

            $rowId = (int)$r['id'];
            $q     = (int)$r['quantity'];
            $res   = (int)$r['reserved_quantity'];

            // Biztonság: ne menjünk reserved alá
            $freeHere = max(0, $q - $res);
            if ($freeHere <= 0) continue;

            $take = min($freeHere, $remaining);
            $newQ = $q - $take;

            $updRow->bind_param("ii", $newQ, $rowId);
            $updRow->execute();

            $remaining -= $take;
          }

          if ($remaining > 0) {
            // Elvileg nem történhet, mert checkeltük,
            // de konkurens vásárlásnál előfordulhat.
            throw new Exception("A termék készlete időközben megváltozott (ID: {$pid}). Próbáld újra.");
          }
        }

        $selRows->close();
        $updRow->close();

        $mysqli->commit();
        cart_clear();

        header("Location: rendeles_sikeres.php?id=" . $order_id);
        exit;

      } catch (Throwable $e) {
        $mysqli->rollback();
        $err = "Hiba történt a rendelés mentésekor: " . $e->getMessage();
      }
    }
  }
}

$total = cart_total($mysqli);
?>
<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <title>Pénztár | Raktár Pro</title>
  <link rel="stylesheet" href="style_home.css">
  <style>
    .wrap{width:min(900px,94vw);margin:24px auto;display:grid;gap:16px}
    .card{background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:16px}
    .grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
    .full{grid-column:1/-1}
    label{font-weight:700;margin-bottom:6px;display:block}
    input, textarea, select{width:100%;padding:10px;border:1px solid #e5e7eb;border-radius:10px}
    .btn{display:inline-flex;gap:8px;align-items:center;background:#111827;color:#fff;border:none;border-radius:10px;padding:10px 12px;cursor:pointer;text-decoration:none}
    .btn.outline{background:#fff;color:#111827;border:1px solid #111827}
    .note{padding:10px 12px;border-radius:10px;margin-bottom:12px}
    .error{background:#fef2f2;border:1px solid #fecaca;color:#7f1d1d}
    .summary{background:#f9fafb;border:1px solid #e5e7eb;border-radius:10px;padding:12px}
  </style>
</head>
<body>

<div class="wrap">
  <div class="card">
    <h2 style="margin:0 0 12px">🧾 Pénztár</h2>

    <?php if ($err): ?><div class="note error"><?php echo h($err); ?></div><?php endif; ?>

    <form method="post" class="grid">
      <input type="hidden" name="csrf" value="<?php echo h($csrf); ?>">

      <div>
        <label>Név</label>
        <input type="text" name="nev" value="<?php echo h($pref_nev); ?>" required>
      </div>
      <div>
        <label>E-mail</label>
        <input type="email" name="email" value="<?php echo h($pref_email); ?>" required>
      </div>
      <div class="full">
        <label>Szállítási cím</label>
        <input type="text" name="cim" placeholder="Irányítószám, város, utca, házszám" value="<?php echo h($pref_cim); ?>" required>
      </div>
      <div>
        <label>Fizetési mód</label>
        <select name="fizetes_mod">
          <option value="utanvet">Utánvét</option>
          <option value="bankkartya" disabled>Bankkártya (hamarosan)</option>
        </select>
      </div>
      <div class="summary">
        <div style="display:flex;justify-content:space-between">
          <div>Végösszeg:</div>
          <strong><?php echo number_format((int)$total, 0, '', ' '); ?> Ft</strong>
        </div>
      </div>

      <div class="full" style="display:flex;justify-content:flex-end;gap:8px">
        <a class="btn outline" href="kosar.php">← Vissza a kosárhoz</a>
        <button class="btn" type="submit">Rendelés leadása</button>
      </div>
    </form>
  </div>
</div>
</body>
</html>
