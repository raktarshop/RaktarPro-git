<?php
/**
 * Raktár Pro – config.template.php
 * 
 * FONTOS: Másold át ezt config.php néven és töltsd ki az érzékeny adatokat!
 * 
 * Telepítés után:
 * 1. cp config.template.php config.php
 * 2. Szerkeszd a config.php-t és állítsd be:
 *    - Adatbázis jelszó
 *    - JWT secret (random hosszú string)
 *    - COOKIE_SECURE (true ha HTTPS)
 */

declare(strict_types=1);
define('APP_BASE', '/raktar_pro');

// ===============================
// 🔧 Alap beállítások (MAMP)
// ===============================
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = 'CHANGE_THIS_PASSWORD';  // ← TÖLTSD KI!
$DB_NAME = 'webaruhaz';
$DB_PORT = 8889;  // MAMP alapértelmezett port
$DB_SOCK = '/Applications/MAMP/tmp/mysql/mysql.sock';  // MAMP socket

// ===============================
// 🧱 Adatbázis kapcsolat
// ===============================
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME, $DB_PORT);
} catch (Throwable $e) {
    // Fallback socket használat
    $mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME, null, $DB_SOCK);
}
$mysqli->set_charset('utf8mb4');

// ===============================
// 🕒 Időzóna
// ===============================
date_default_timezone_set('Europe/Budapest');

// ===============================
// 🔒 Session
// ===============================
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'secure'   => false,  // ← false MAMP-on (http), true production-on (https)
        'samesite' => 'Lax',
    ]);
    session_start();
}

// ===============================
// 🔑 JWT KONSTANSOK
// ===============================
const JWT_SECRET       = 'CHANGE_THIS_TO_LONG_RANDOM_STRING_MIN_32_CHARS';  // ← TÖLTSD KI!
const JWT_ISS          = 'raktarpro';
const ACCESS_TTL       = 900;      // 15 perc
const REFRESH_TTL      = 1209600;  // 14 nap

// Cookie beállítások (refresh tokenhez)
const REFRESH_COOKIE  = 'rp_refresh';
const COOKIE_SECURE   = false;   // ← false MAMP-on, true production-on
const COOKIE_SAMESITE = 'Lax';
const COOKIE_DOMAIN   = '';      // Üresen hagyható lokálisan
const COOKIE_PATH     = '/';     // Fontos: gyökér legyen!

// ===============================
// 🧩 Segédfüggvények
// ===============================

// HTML escapelés
if (!function_exists('h')) {
    function h(?string $s): string {
        return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
    }
}

// Session-alapú jogosultság (átmenetileg megtartva JWT mellett)
if (!function_exists('is_logged_in')) {
    function is_logged_in(): bool {
        return isset($_SESSION['user_id']) && (int)$_SESSION['user_id'] > 0;
    }
}

if (!function_exists('is_admin')) {
    function is_admin(): bool {
        return isset($_SESSION['szerepkor_id']) && (int)$_SESSION['szerepkor_id'] === 1;
    }
}

// CSRF segédek
if (!function_exists('csrf_token')) {
    function csrf_token(): string {
        if (empty($_SESSION['csrf'])) {
            $_SESSION['csrf'] = bin2hex(random_bytes(16));
        }
        return $_SESSION['csrf'];
    }
}

if (!function_exists('csrf_verify')) {
    function csrf_verify(?string $token): bool {
        return isset($_SESSION['csrf']) && is_string($token) && hash_equals($_SESSION['csrf'], $token);
    }
}

// ===============================
// 📝 TELEPÍTÉSI JEGYZETEK
// ===============================
/*

LÉPÉSEK A TELEPÍTÉSHEZ:

1. ADATBÁZIS JELSZÓ BEÁLLÍTÁSA:
   - $DB_PASS = 'root';  // vagy saját jelszó

2. JWT SECRET GENERÁLÁSA:
   - Terminálban futtatd:
     php -r "echo bin2hex(random_bytes(32));"
   - Másold be a JWT_SECRET-hez

3. HTTPS ELLENŐRZÉS:
   - Ha HTTPS van: COOKIE_SECURE = true
   - Ha HTTP van (MAMP): COOKIE_SECURE = false

4. COMPOSER TELEPÍTÉS:
   cd /path/to/raktar_pro
   composer install

5. UPLOADS MAPPA JOGOSULTSÁG:
   mkdir -p uploads/termekek
   chmod 775 uploads/termekek

6. ADATBÁZIS IMPORT:
   mysql -u root -p webaruhaz < database.sql

7. TESZTELÉS:
   http://localhost:8888/raktar_pro/

*/