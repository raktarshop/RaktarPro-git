<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/cart_utils.php';

/**
 * AJAX/fetch kompatibilis detektálás:
 * - X-Requested-With (klasszikus)
 * - Accept: application/json (fetch)
 * - ?ajax=1 (kézi kényszerítés)
 */
$isAjax = (
  (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
  || (!empty($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false)
  || (isset($_GET['ajax']) && $_GET['ajax'] == '1')
);

function json_out(int $code, array $payload): void {
  http_response_code($code);
  header('Content-Type: application/json; charset=utf-8');
  header('Cache-Control: no-cache, must-revalidate');
  echo json_encode($payload, JSON_UNESCAPED_UNICODE);
  exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  if ($isAjax) json_out(405, ['success' => false, 'error' => 'Method Not Allowed']);
  http_response_code(405);
  exit('Hibás kérés.');
}

$termek_id = (int)($_POST['termek_id'] ?? 0);
$qty       = max(1, (int)($_POST['qty'] ?? 1));

if ($termek_id <= 0) {
  if ($isAjax) json_out(400, ['success' => false, 'error' => 'Hiányzó termék azonosító']);
  http_response_code(400);
  exit('Hiányzó termék azonosító.');
}

/**
 * VALÓS KÉSZLET az SQL-ből (stock tábla alapján)
 * A phpMyAdmin képed szerint a stock tábla mezői:
 * - product_id
 * - quantity
 * - reserved_quantity
 *
 * Valós elérhető készlet = SUM(quantity - reserved_quantity) (összes lokáció)
 */
$stmt = $mysqli->prepare("
  SELECT
    p.id,
    p.name AS nev,
    COALESCE(SUM(s.quantity), 0) AS keszlet_osszes,
    COALESCE(SUM(s.reserved_quantity), 0) AS foglalt_osszes,
    GREATEST(COALESCE(SUM(s.quantity - s.reserved_quantity), 0), 0) AS keszlet_elerheto
  FROM products p
  LEFT JOIN stock s ON s.product_id = p.id
  WHERE p.id = ?
  GROUP BY p.id, p.name
");
if (!$stmt) {
  if ($isAjax) json_out(500, ['success' => false, 'error' => 'SQL prepare hiba']);
  http_response_code(500);
  exit('SQL prepare hiba.');
}

$stmt->bind_param("i", $termek_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$result) {
  if ($isAjax) json_out(404, ['success' => false, 'error' => 'Ismeretlen termék']);
  http_response_code(404);
  exit('Ismeretlen termék.');
}

// Készlet ellenőrzés (VALÓS, foglalást levonva)
$keszlet_elerheto = (int)($result['keszlet_elerheto'] ?? 0);

if ($qty > $keszlet_elerheto) {
  $msg = 'Nincs elegendő készlet. Elérhető: ' . $keszlet_elerheto . ' db';
  if ($isAjax) {
    json_out(400, [
      'success'   => false,
      'error'     => $msg,
      'available' => $keszlet_elerheto,
      'stock'     => [
        'total'     => (int)($result['keszlet_osszes'] ?? 0),
        'reserved'  => (int)($result['foglalt_osszes'] ?? 0),
        'available' => $keszlet_elerheto,
      ]
    ]);
  }
  http_response_code(400);
  exit($msg);
}

// Kosárba helyezés
cart_add($termek_id, $qty);

// AJAX válasz (fetch-nek EZ KELL)
if ($isAjax) {
  json_out(200, [
    'success' => true,
    'message' => 'Termék hozzáadva a kosárhoz',
    'product' => [
      'id'  => $termek_id,
      'nev' => (string)($result['nev'] ?? ''),
      'qty' => $qty
    ],
    'stock' => [
      'total'     => (int)($result['keszlet_osszes'] ?? 0),
      'reserved'  => (int)($result['foglalt_osszes'] ?? 0),
      'available' => $keszlet_elerheto,
    ],
    'cart' => [
      'count' => cart_count(),
      'total' => cart_total($mysqli)
    ]
  ]);
}

// Nem AJAX: redirect vissza
$back = $_SERVER['HTTP_REFERER'] ?? '/raktar_pro/kosar.php';
header("Location: " . $back);
exit;
