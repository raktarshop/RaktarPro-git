<?php
// backwards-compat: régi, hibás kódolású fájlnév → az újra irányít
require_once __DIR__ . '/rendeles_sikeres.php';
