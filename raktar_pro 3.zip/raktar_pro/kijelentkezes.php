<?php
require_once __DIR__ . '/config.php';

session_unset();
session_destroy();

header("Location: /raktar_pro/login_register.html");
exit;
