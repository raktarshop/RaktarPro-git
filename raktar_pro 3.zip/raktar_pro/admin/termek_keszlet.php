<?php
require_once __DIR__ . '/_init.php';

function h($s){ return htmlspecialchars($s ?? "", ENT_QUOTES, "UTF-8"); }

define('DEFAULT_LOCATION_ID', 9); // E1 id = 9

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) exit('Hibás termék ID.');

// termék név
$stmt = $mysqli->prepare("SELECT id, name AS nev FROM products WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$t = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$t) exit('Termék nem található.');

// aktuális készlet (E1-ből)
$loc = DEFAULT_LOCATION_ID;
$q = $mysqli->prepare("
  SELECT GREATEST(COALESCE(quantity - reserved_quantity, 0), 0) AS keszlet
  FROM stock
  WHERE product_id = ? AND location_id = ?
  LIMIT 1
");
$q->bind_param("ii", $id, $loc);
$q->execute();
$row = $q->get_result()->fetch_assoc();
$q->close();
$t['keszlet'] = (int)($row['keszlet'] ?? 0);

$msg = $err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $uj = max(0, (int)($_POST['keszlet'] ?? 0));

  // van-e már stock sor?
  $check = $mysqli->prepare("SELECT id FROM stock WHERE product_id=? AND location_id=? LIMIT 1");
  $check->bind_param("ii", $id, $loc);
  $check->execute();
  $existing = $check->get_result()->fetch_assoc();
  $check->close();

  if ($existing) {
    $sid = (int)$existing['id'];
    $upd = $mysqli->prepare("UPDATE stock SET quantity=?, reserved_quantity=0 WHERE id=?");
    $upd->bind_param("ii", $uj, $sid);
  } else {
    $upd = $mysqli->prepare("INSERT INTO stock (product_id, location_id, quantity, reserved_quantity) VALUES (?,?,?,0)");
    $upd->bind_param("iii", $id, $loc, $uj);
  }

  if ($upd->execute()) {
    $msg = "Készlet frissítve (E1): {$uj} db";
    $t['keszlet'] = $uj; // hogy azonnal frissüljön a mezőben
  } else {
    $err = "Hiba: " . $upd->error;
  }
  $upd->close();
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <title>Készlet módosítása</title>
  <link rel="stylesheet" href="style_admin.css">
</head>
<body>
<div class="container">
  <div class="card">
    <h1>📦 Készlet módosítása</h1>
    <?php if($msg): ?><div class="notice"><?php echo h($msg); ?></div><?php endif; ?>
    <?php if($err): ?><div class="error"><?php echo h($err); ?></div><?php endif; ?>

    <form method="post" class="row" style="gap:8px">
      <label>Termék: <strong><?php echo h($t['nev']); ?></strong></label>
      <input type="number" name="keszlet" value="<?php echo (int)$t['keszlet']; ?>" min="0">
      <button class="btn" type="submit">Mentés</button>
      <a class="btn outline" href="termekek.php">Vissza</a>
    </form>
  </div>
</div>
</body>
</html>
