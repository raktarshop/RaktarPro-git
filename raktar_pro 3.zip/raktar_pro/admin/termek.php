<?php
require_once __DIR__ . '/_init.php'; // admin check, $mysqli, h()

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) exit('Hibás termék azonosító.');

$stmt = $mysqli->prepare("
  SELECT
    p.id,
    p.sku,
    p.name,
    p.description,
    p.unit_price,
    p.image_url,
    c.name AS category_name,
    GREATEST(COALESCE(SUM(s.quantity - s.reserved_quantity),0),0) AS available_total
  FROM products p
  LEFT JOIN categories c ON c.id = p.category_id
  LEFT JOIN stock s ON s.product_id = p.id
  WHERE p.id = ?
  GROUP BY p.id, p.sku, p.name, p.description, p.unit_price, p.image_url, c.name
  LIMIT 1
");
$stmt->bind_param("i", $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$product) exit('Termék nem található.');

// Lokációnkénti bontás (ha van locations/warehouses)
$rows = [];
try {
  $q = $mysqli->prepare("
    SELECT
      w.name AS warehouse,
      l.code AS location_code,
      s.quantity,
      s.reserved_quantity,
      GREATEST(s.quantity - s.reserved_quantity, 0) AS available
    FROM stock s
    JOIN locations l ON l.id = s.location_id
    JOIN warehouses w ON w.id = l.warehouse_id
    WHERE s.product_id = ?
    ORDER BY w.name, l.code
  ");
  $q->bind_param("i", $id);
  $q->execute();
  $rows = $q->get_result()->fetch_all(MYSQLI_ASSOC);
  $q->close();
} catch (Throwable $e) {
  // ha nincs modul, üres marad
}
?>
<!doctype html>
<html lang="hu">
<head>
  <meta charset="utf-8">
  <title>Admin – Termék #<?php echo (int)$product['id']; ?></title>
  <link rel="stylesheet" href="style_admin.css">
  <style>
    .container{width:min(1100px,94vw);margin:20px auto}
    .card{background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:16px;margin-bottom:16px}
    .row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
    .grid{display:grid;grid-template-columns:1fr 1.2fr;gap:16px}
    .img{width:100%;aspect-ratio:1/1;object-fit:contain;border:1px solid #e5e7eb;border-radius:12px;background:#fafafa}
    .badge{display:inline-block;padding:4px 10px;border-radius:9999px;border:1px solid #e5e7eb;background:#f9fafb}
    .table{width:100%;border-collapse:collapse}
    .table th,.table td{padding:10px;border-bottom:1px solid #e5e7eb;text-align:left}
    .btn{display:inline-flex;gap:8px;align-items:center;background:#111827;color:#fff;border:none;border-radius:10px;padding:10px 12px;text-decoration:none;cursor:pointer}
    .btn.outline{background:#fff;color:#111827;border:1px solid #111827}
    .muted{color:#6b7280}
  </style>
</head>
<body>
<div class="container">

  <div class="card">
    <div class="row" style="justify-content:space-between">
      <h1>🧾 Termék #<?php echo (int)$product['id']; ?></h1>
      <div class="row">
        <a class="btn outline" href="/raktar_pro/admin/termekek.php">← Termékek</a>
        <a class="btn outline" href="/raktar_pro/index.php">🏪 Bolt</a>
      </div>
    </div>

    <div class="grid">
      <div class="card" style="margin:0">
        <?php if (!empty($product['image_url'])): ?>
          <img class="img" src="<?php echo h($product['image_url']); ?>" alt="">
        <?php else: ?>
          <div class="img" style="display:grid;place-items:center;color:#9ca3af">Nincs kép</div>
        <?php endif; ?>
      </div>

      <div class="card" style="margin:0">
        <div class="muted">Kategória: <?php echo h($product['category_name'] ?? '—'); ?> • SKU: <?php echo h($product['sku'] ?? '—'); ?></div>
        <h2 style="margin:10px 0 6px 0"><?php echo h($product['name']); ?></h2>

        <div style="font-size:22px;font-weight:900">
          <?php echo number_format((int)$product['unit_price'], 0, '', ' '); ?> Ft
          <?php if ((int)$product['available_total'] <= 0): ?>
            <span class="badge" style="background:#fee2e2;color:#991b1b;border:1px solid #fecaca">Nincs készleten</span>
          <?php else: ?>
            <span class="badge" style="background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0">
              Elérhető összesen: <?php echo (int)$product['available_total']; ?> db
            </span>
          <?php endif; ?>
        </div>

        <p class="muted" style="margin-top:10px;white-space:pre-line"><?php echo h($product['description']); ?></p>

        <div class="row" style="margin-top:12px">
          <a class="btn" href="/raktar_pro/admin/keszlet_szerkeszt.php?product_id=<?php echo (int)$product['id']; ?>">📦 Készlet módosítása</a>
          <a class="btn outline" href="/raktar_pro/termek.php?id=<?php echo (int)$product['id']; ?>">👁️ Megnézés a boltban</a>
        </div>
      </div>
    </div>
  </div>

  <?php if (!empty($rows)): ?>
    <div class="card">
      <h3 style="margin-top:0">Készlet helyenként (elérhető = quantity - reserved)</h3>
      <table class="table">
        <thead>
          <tr>
            <th>Raktár</th>
            <th>Hely</th>
            <th>Quantity</th>
            <th>Reserved</th>
            <th>Elérhető</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td><?php echo h($r['warehouse']); ?></td>
              <td><?php echo h($r['location_code']); ?></td>
              <td><?php echo (int)$r['quantity']; ?></td>
              <td><?php echo (int)$r['reserved_quantity']; ?></td>
              <td><strong><?php echo (int)$r['available']; ?></strong></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <div class="muted" style="margin-top:8px">A fenti táblázat ugyanazt az összkészletet bontja fel, nem “második” készlet.</div>
    </div>
  <?php endif; ?>

</div>
</body>
</html>
