<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

$cart = $_SESSION['cart'] ?? []; // pl. [productId => qty]
$count = 0;

foreach ($cart as $qty) {
  $count += (int)$qty;
}

echo json_encode([
  'count' => $count
]);
