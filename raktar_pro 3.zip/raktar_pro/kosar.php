<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/cart_utils.php';

function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

$items = cart_items($mysqli);
$total = cart_total($mysqli);

// --- VALÓS KÉSZLET lekérése a stock táblából (összes lokáció, reserved levonva) ---
$availability = []; // product_id => available

if (!empty($items)) {
  // készítsünk egy IN (?) listát biztonságosan
  $ids = array_values(array_unique(array_map(fn($it) => (int)$it['id'], $items)));
  $placeholders = implode(',', array_fill(0, count($ids), '?'));
  $types = str_repeat('i', count($ids));

  $sql = "
    SELECT
      p.id AS product_id,
      GREATEST(COALESCE(SUM(s.quantity - s.reserved_quantity), 0), 0) AS available
    FROM products p
    LEFT JOIN stock s ON s.product_id = p.id
    WHERE p.id IN ($placeholders)
    GROUP BY p.id
  ";

  $stmt = $mysqli->prepare($sql);
  if ($stmt) {
    $stmt->bind_param($types, ...$ids);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
      $availability[(int)$row['product_id']] = (int)$row['available'];
    }
    $stmt->close();
  } else {
    // ha valamiért nem sikerül, maradjon 0 (biztonság: checkout tiltás)
    foreach ($ids as $pid) $availability[(int)$pid] = 0;
  }
}

// --- Validáció: van-e olyan tétel, ami nem vehető meg? ---
$hasProblem = false;
$problems = []; // pid => msg

foreach ($items as $it) {
  $pid = (int)$it['id'];
  $qty = (int)$it['qty'];
  $avail = (int)($availability[$pid] ?? 0);

  if ($avail <= 0) {
    $hasProblem = true;
    $problems[$pid] = 'Jelenleg nincs készleten.';
  } elseif ($qty > $avail) {
    $hasProblem = true;
    $problems[$pid] = 'Nem elegendő készlet. Elérhető: ' . $avail . ' db.';
  }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <title>Kosár – Raktár Pro</title>

  <!-- SAJÁT CSS -->
  <link rel="stylesheet" href="/raktar_pro/assets/css/variables.css">
  <link rel="stylesheet" href="/raktar_pro/assets/css/base.css">
  <link rel="stylesheet" href="/raktar_pro/assets/css/components.css">
  <link rel="stylesheet" href="/raktar_pro/assets/css/layout.css">
  <link rel="stylesheet" href="/raktar_pro/assets/css/kosar.css">

  <style>
    /* =========================
   KOSÁR – RAKTÁR PRO
   Modern Premium Design
   ========================= */

.cart-page {
  max-width: 1200px;
  margin: 60px auto;
  padding: 0 24px;
  position: relative;
}

.cart-page::before {
  content: '';
  position: absolute;
  top: -100px;
  right: -100px;
  width: 400px;
  height: 400px;
  background: radial-gradient(circle, rgba(59, 130, 246, 0.08) 0%, transparent 70%);
  border-radius: 50%;
  pointer-events: none;
  animation: float 8s ease-in-out infinite;
}

@keyframes float {
  0%, 100% { transform: translateY(0px) rotate(0deg); }
  50% { transform: translateY(-20px) rotate(5deg); }
}

.cart-page h1 {
  font-size: 2.5rem;
  font-weight: 900;
  margin-bottom: 40px;
  display: flex;
  align-items: center;
  gap: 16px;
  background: linear-gradient(135deg, #1e40af, #3b82f6, #60a5fa);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  letter-spacing: -0.02em;
  position: relative;
  animation: slideInDown 0.6s ease-out;
}

@keyframes slideInDown {
  from { opacity: 0; transform: translateY(-20px); }
  to { opacity: 1; transform: translateY(0); }
}
  </style>
</head>
<body>

<div class="cart-page">

  <h1>🛒 Kosár</h1>

  <?php if (empty($items)): ?>

    <!-- ÜRES KOSÁR -->
    <div class="cart-empty-box">
      <p>A kosarad jelenleg üres.</p>
      <a href="/raktar_pro/index.php" class="btn btn-primary">
        Vásárlás folytatása
      </a>
    </div>

  <?php else: ?>

    <?php if ($hasProblem): ?>
      <div class="cart-blocker">
        Van olyan termék a kosárban, ami jelenleg nem rendelhető. Kérlek távolítsd el, vagy csökkentsd a darabszámot.
      </div>
    <?php endif; ?>

    <!-- KOSÁR TÁBLA -->
    <table class="cart-table">
      <thead>
        <tr>
          <th>Termék</th>
          <th>Ár</th>
          <th>Db</th>
          <th>Összesen</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($items as $i): ?>
          <?php
            $pid = (int)$i['id'];
            $qty = (int)$i['qty'];
            $avail = (int)($availability[$pid] ?? 0);
            $problem = $problems[$pid] ?? '';
          ?>
          <tr>

            <!-- TERMÉK -->
            <td>
              <div class="cart-product">
                <?php if (!empty($i['kep_url'])): ?>
                  <img src="<?= h($i['kep_url']) ?>" alt="<?= h($i['nev']) ?>">
                <?php endif; ?>
                <span class="cart-product-name">
                  <?= h($i['nev']) ?>
                </span>
              </div>

              <?php if ($problem): ?>
                <!-- NEM MUTATUNK 0 DB-ot, csak státuszt -->
                <div class="stock-note bad">
                  <?= h($problem) ?>
                </div>
              <?php else: ?>
                <!-- Ha minden oké, nem muszáj készletet kiírni -->
                <div class="stock-note">
                  Készleten
                </div>
              <?php endif; ?>

            </td>

            <!-- ÁR -->
            <td class="cart-price">
              <?= number_format((int)$i['egysegar'], 0, ' ', ' ') ?> Ft
            </td>

            <!-- DB -->
            <td class="cart-qty">
              <?= $qty ?>
            </td>

            <!-- ÖSSZEG -->
            <td class="cart-subtotal">
              <?= number_format((int)$i['subtotal'], 0, ' ', ' ') ?> Ft
            </td>

            <!-- TÖRLÉS -->
            <td>
              <a
                href="/raktar_pro/cart_remove.php?id=<?= $pid ?>"
                class="cart-remove"
                title="Eltávolítás"
              >
                ❌
              </a>
            </td>

          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <!-- ÖSSZESÍTŐ -->
    <div class="cart-summary">
      <div class="cart-total">
        Összesen: <span><?= number_format((int)$total, 0, ' ', ' ') ?> Ft</span>
      </div>

      <div class="cart-actions">
        <a href="/raktar_pro/index.php" class="btn btn-outline">
          ← Vásárlás folytatása
        </a>

        <?php if ($hasProblem): ?>
          <a href="#" class="btn btn-primary disabled" aria-disabled="true" title="Van nem rendelhető termék a kosárban">
            Tovább a fizetéshez →
          </a>
        <?php else: ?>
          <a href="/raktar_pro/checkout.php" class="btn btn-primary">
            Tovább a fizetéshez →
          </a>
        <?php endif; ?>
      </div>
    </div>

  <?php endif; ?>

</div>

</body>
</html>
