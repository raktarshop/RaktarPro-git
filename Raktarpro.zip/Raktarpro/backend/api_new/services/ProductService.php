<?php
/**
 * Product Service
 * Termék business logic
 */

require_once __DIR__ . '/../models/ProductModel.php';
require_once __DIR__ . '/../utils/Validator.php';

class ProductService {
    
    private ProductModel $productModel;
    
    public function __construct() {
        $this->productModel = new ProductModel();
    }
    
    /**
     * Apply language-specific fields to product output.
     * If name_{lang}/description_{lang} exists and not empty, it replaces name/description.
     */
    private function applyProductLang(array $p, string $lang): array {
        $lang = in_array($lang, ['hu','en','de'], true) ? $lang : 'hu';

        $nameKey = 'name_' . $lang;
        $descKey = 'description_' . $lang;

        if (isset($p[$nameKey]) && $p[$nameKey] !== null && trim((string)$p[$nameKey]) !== '') {
            $p['name'] = $p[$nameKey];
        }
        if (isset($p[$descKey]) && $p[$descKey] !== null && trim((string)$p[$descKey]) !== '') {
            $p['description'] = $p[$descKey];
        }

        return $p;
    }

    /**
     * Normalize image list for frontend (details modal / carousel)
     * - Supports: image_url, image_urls (JSON array or comma-separated), images (array)
     */
    private function applyImages(array $p): array {
        $images = [];

        // image_urls column (json or csv)
        if (isset($p['image_urls']) && $p['image_urls'] !== null && $p['image_urls'] !== '') {
            $raw = $p['image_urls'];
            if (is_string($raw)) {
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) {
                    foreach ($decoded as $u) {
                        if (is_string($u) && trim($u) !== '') $images[] = trim($u);
                    }
                } else {
                    // csv fallback
                    foreach (explode(',', $raw) as $u) {
                        $u = trim($u);
                        if ($u !== '') $images[] = $u;
                    }
                }
            } elseif (is_array($raw)) {
                foreach ($raw as $u) {
                    if (is_string($u) && trim($u) !== '') $images[] = trim($u);
                }
            }
        }

        // images array
        if (isset($p['images']) && is_array($p['images'])) {
            foreach ($p['images'] as $u) {
                if (is_string($u) && trim($u) !== '') $images[] = trim($u);
            }
        }

        // image_url single
        if (isset($p['image_url']) && is_string($p['image_url']) && trim($p['image_url']) !== '') {
            $images[] = trim($p['image_url']);
        }

        // unique + max 4
        $images = array_values(array_unique(array_filter($images, fn($x) => is_string($x) && trim($x) !== '')));
        $p['images'] = array_slice($images, 0, 4);

        return $p;
    }


    /**
     * Get products with pagination and filters
     */
    public function getProducts(array $filters = [], string $lang = "hu"): array {
        $pagination = Validator::getPaginationParams($filters);
        
        $products = $this->productModel->getProducts([
            'search'     => $filters['search']     ?? '',
            'category_id'=> $filters['category_id']?? null,
            'sort'       => $filters['sort']        ?? 'newest',
            'limit'      => $pagination['limit'],
            'offset'     => $pagination['offset'],
            'price_min'  => $filters['price_min']  ?? '',
            'price_max'  => $filters['price_max']  ?? '',
            'min_rating' => $filters['min_rating'] ?? '',
            'in_stock'   => $filters['in_stock']   ?? '',
        ]);
        
        
        $products = array_map(fn($p) => $this->applyImages($this->applyProductLang($p, $lang)), $products);

        $total = $this->productModel->countProducts([
            'search' => $filters['search'] ?? '',
            'category_id' => $filters['category_id'] ?? null
        ]);
        
        return [
            'products' => $products,
            'pagination' => [
                'page' => $pagination['page'],
                'limit' => $pagination['limit'],
                'total' => $total,
                'pages' => ceil($total / $pagination['limit'])
            ]
        ];
    }
    
    /**
     * Get product by ID
     */
    public function getProduct(int $id, string $lang = "hu"): ?array {
        $p = $this->productModel->getProductDetails($id);
        if (!$p) return null;
        $p = $this->applyProductLang($p, $lang);
        return $this->applyImages($p);
    }

    /**
     * Get products by ID list (for cart)
     */
    public function getProductsByIds(array $ids, string $lang = "hu"): array {
        if (empty($ids)) return [];
        // ProductModel already has getByIds([...])
        $products = $this->productModel->getByIds($ids);
        $products = array_map(fn($p) => $this->applyImages($this->applyProductLang($p, $lang)), $products);
        return $products;
    }
    
    /**
     * Create product (ADMIN)
     */
    public function createProduct(array $data): int {
        // Validate required
        $errors = Validator::required($data, ['sku', 'name', 'unit_price']);
        
        if (!empty($errors)) {
            throw new Exception(json_encode($errors));
        }
        
        // Check SKU uniqueness
        if ($this->productModel->skuExists($data['sku'])) {
            throw new Exception('Ez a cikkszám már létezik');
        }
        
        // Prepare data
        $productData = [
            'sku' => Validator::sanitizeString($data['sku']),
            'name' => Validator::sanitizeString($data['name']),
            'description' => $data['description'] ?? null,
            'unit_price' => (float)$data['unit_price'],
            'stock' => (int)($data['stock'] ?? 0),
            'category_id' => !empty($data['category_id']) ? (int)$data['category_id'] : null,
            'supplier_id' => !empty($data['supplier_id']) ? (int)$data['supplier_id'] : null,
            'weight' => !empty($data['weight']) ? (float)$data['weight'] : null,
            'image_url' => $data['image_url'] ?? null,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        return $this->productModel->create($productData);
    }
    
    /**
     * Update product (ADMIN)
     */
    public function updateProduct(int $id, array $data): bool {
        // Check product exists
        $product = $this->productModel->find($id);
        if (!$product) {
            throw new Exception('Termék nem található');
        }
        
        // Check SKU uniqueness if changed
        if (!empty($data['sku']) && $this->productModel->skuExists($data['sku'], $id)) {
            throw new Exception('Ez a cikkszám már létezik');
        }
        
        // IMPORTANT:
        // ProductModel->update() stored procedure expects *all* fields.
        // So we merge current DB values with incoming partial payload,
        // otherwise missing keys would overwrite fields with NULL/0.

        $merged = [
            'sku' => $product['sku'] ?? '',
            'name' => $product['name'] ?? '',
            'description' => $product['description'] ?? null,
            'image_url' => $product['image_url'] ?? null,
            'category_id' => $product['category_id'] ?? null,
            'supplier_id' => $product['supplier_id'] ?? null,
            'unit_price' => $product['unit_price'] ?? 0,
            'weight' => $product['weight'] ?? null,
            'stock' => $product['stock'] ?? 0,
        ];

        if (array_key_exists('sku', $data)) $merged['sku'] = Validator::sanitizeString($data['sku']);
        if (array_key_exists('name', $data)) $merged['name'] = Validator::sanitizeString($data['name']);
        if (array_key_exists('description', $data)) $merged['description'] = $data['description'];
        if (array_key_exists('image_url', $data)) $merged['image_url'] = $data['image_url'] ?: null;

        if (array_key_exists('category_id', $data)) {
            $merged['category_id'] = ($data['category_id'] === null || $data['category_id'] === '' ) ? null : (int)$data['category_id'];
        }
        if (array_key_exists('supplier_id', $data)) {
            $merged['supplier_id'] = ($data['supplier_id'] === null || $data['supplier_id'] === '' ) ? null : (int)$data['supplier_id'];
        }

        if (array_key_exists('unit_price', $data)) $merged['unit_price'] = (float)$data['unit_price'];
        if (array_key_exists('weight', $data)) $merged['weight'] = ($data['weight'] === null || $data['weight'] === '') ? null : (float)$data['weight'];
        if (array_key_exists('stock', $data)) $merged['stock'] = (int)$data['stock'];

        $merged['updated_at'] = date('Y-m-d H:i:s');

        return $this->productModel->update($id, $merged);
    }
    
    /**
     * Delete product (ADMIN)
     */
    public function deleteProduct(int $id): bool {
        // Check product exists
        $product = $this->productModel->find($id);
        if (!$product) {
            throw new Exception('Termék nem található');
        }
        
        return $this->productModel->delete($id);
    }
}
