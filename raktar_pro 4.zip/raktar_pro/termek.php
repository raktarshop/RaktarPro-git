<?php
require_once __DIR__ . '/config.php';

function h($s){ return htmlspecialchars($s ?? "", ENT_QUOTES, "UTF-8"); }
$id = intval($_GET['id'] ?? 0);
if ($id <= 0) { http_response_code(404); exit('Termék nem található.'); }

/**
 * Termék + kategória + VALÓS készlet (stockból számolva, reserved levonva)
 * available = SUM(quantity - reserved_quantity)
 */
$stmt = $mysqli->prepare("
  SELECT
    t.id,
    t.sku AS cikkszam,
    t.name AS nev,
    t.description AS leiras,
    t.unit_price AS egysegar,
    t.image_url AS kep_url,
    k.name AS kategoria,
    GREATEST(COALESCE(SUM(s.quantity - s.reserved_quantity), 0), 0) AS available
  FROM products t
  LEFT JOIN categories k ON k.id = t.category_id
  LEFT JOIN stock s ON s.product_id = t.id
  WHERE t.id = ?
  GROUP BY t.id, t.sku, t.name, t.description, t.unit_price, t.image_url, k.name
  LIMIT 1
");
$stmt->bind_param("i", $id);
$stmt->execute();
$termek = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$termek) { http_response_code(404); exit('Termék nem található.'); }

/**
 * Készlet lokációnként (ELÉRHETŐ: quantity - reserved_quantity)
 */
$keszletek = [];
try {
  $q = $mysqli->prepare("
    SELECT
      w.name AS raktar,
      l.code AS hely,
      GREATEST(s.quantity - s.reserved_quantity, 0) AS mennyiseg
    FROM stock s
    JOIN locations l ON l.id = s.location_id
    JOIN warehouses w ON w.id = l.warehouse_id
    WHERE s.product_id = ?
    ORDER BY w.name, l.code
  ");
  $q->bind_param("i", $id);
  $q->execute();
  $keszletek = $q->get_result()->fetch_all(MYSQLI_ASSOC);
  $q->close();
} catch (Throwable $e) {
  // ha nincs locations/warehouses modul, hagyjuk üresen
}

$available_total = (int)($termek['available'] ?? 0);
?>
<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?php echo h($termek['nev']); ?> – Raktár Pro</title>

  <!-- meglévő oldal stílus -->
  <link rel="stylesheet" href="style_home.css" />

  <!-- toast (ugyanaz, mint a főoldalon) -->
  <link rel="stylesheet" href="/raktar_pro/assets/css/toast.css" />

  <style>
/* ===== Modern blue shop UI (drop-in override) ===== */

:root{
  --primary: #2563eb;        /* kék */
  --primary-600: #1d4ed8;
  --bg: #f6f8ff;
  --card: #ffffff;
  --text: #0f172a;
  --muted: #64748b;
  --border: rgba(15, 23, 42, .10);
  --shadow: 0 12px 30px rgba(2, 6, 23, .10);
  --shadow-soft: 0 8px 18px rgba(2, 6, 23, .08);
}

.wrap{
  width: min(1120px, 94vw);
  margin: 24px auto;
  display: grid;
  grid-template-columns: 1fr 1.2fr;
  gap: 24px;
}

@media (max-width: 900px){
  .wrap{ grid-template-columns: 1fr; }
}

/* Card = modernebb border + shadow + “highlight” */
.card{
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 18px;
  padding: 18px;
  box-shadow:
    0 1px 0 rgba(255,255,255,.9) inset,
    var(--shadow-soft);
}

/* Kép doboz: glassy + kék fény */
.imgbox{
  background:
    radial-gradient(900px 300px at 50% -10%, rgba(37,99,235,.22), transparent 55%),
    linear-gradient(180deg, #eef2ff, #f8fbff);
  border: 1px solid rgba(37,99,235,.14);
  border-radius: 16px;
  display: grid;
  place-items: center;
  aspect-ratio: 1/1;
  overflow: hidden;
  box-shadow: 0 10px 22px rgba(37,99,235,.08);
}

/* Ha hover van a képen: nagyon finom “zoom” */
.imgbox img{
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
  transform: scale(1.001);
  transition: transform .45s cubic-bezier(.2,.8,.2,1);
}
.card:hover .imgbox img{ transform: scale(1.04); }

.title{
  font-size: clamp(22px, 2.2vw, 28px);
  font-weight: 900;
  margin: 8px 0 4px;
  color: var(--text);
  letter-spacing: -0.02em;
}

.meta, .crumbs{
  color: var(--muted);
  margin: 4px 0;
  font-size: 14px;
}

.price{
  font-size: clamp(18px, 1.6vw, 22px);
  font-weight: 900;
  margin-top: 10px;
  color: var(--text);
}

.price::after{
  content: "";
  display: block;
  margin-top: 10px;
  height: 1px;
  background: linear-gradient(90deg, rgba(37,99,235,.28), transparent);
}

/* Gombok: primary kék + jobb hover/focus */
.btn{
  display: inline-flex;
  gap: 10px;
  align-items: center;
  justify-content: center;

  background: linear-gradient(180deg, var(--primary), var(--primary-600));
  color: #fff;

  border: 1px solid rgba(37,99,235,.25);
  border-radius: 14px;
  padding: 12px 16px;

  font-weight: 900;
  cursor: pointer;

  box-shadow: 0 10px 18px rgba(37,99,235,.18);
  transition: transform .18s ease, box-shadow .18s ease, filter .18s ease;
}

.btn:hover{
  transform: translateY(-1px);
  filter: saturate(1.05);
  box-shadow: 0 14px 26px rgba(37,99,235,.22);
}

.btn:active{ transform: translateY(0); }

.btn:focus-visible{
  outline: none;
  box-shadow:
    0 14px 26px rgba(37,99,235,.22),
    0 0 0 6px rgba(37,99,235,.18);
}

/* Outline = fehér + kék keret */
.btn.outline{
  background: #fff;
  color: var(--text);
  border: 1px solid rgba(37,99,235,.35);
  box-shadow: 0 10px 18px rgba(2,6,23,.06);
}

.btn.outline:hover{
  box-shadow: 0 14px 26px rgba(2,6,23,.10);
}

/* Mennyiség: modernebb “input chip” */
.qty{
  display: inline-flex;
  align-items: center;
  border: 1px solid var(--border);
  border-radius: 14px;
  overflow: hidden;
  background: #fff;
  box-shadow: 0 8px 16px rgba(2,6,23,.06);
}

.qty input{
  width: 76px;
  padding: 12px 10px;
  border: 0;
  outline: 0;
  text-align: center;
  font-weight: 800;
  color: var(--text);
}

.qty:focus-within{
  border-color: rgba(37,99,235,.45);
  box-shadow:
    0 8px 16px rgba(2,6,23,.06),
    0 0 0 6px rgba(37,99,235,.16);
}

/* Táblázat: tisztább + header finoman kékes */
.table{
  width: 100%;
  border-collapse: collapse;
  margin-top: 12px;
  overflow: hidden;
  border-radius: 14px;
}

.table th,
.table td{
  border-bottom: 1px solid rgba(15, 23, 42, .08);
  padding: 10px 10px;
  text-align: left;
  font-size: 14px;
}

.table th{
  color: var(--text);
  background: linear-gradient(180deg, rgba(37,99,235,.08), rgba(37,99,235,.04));
  font-weight: 900;
}

.table tr:hover td{
  background: rgba(37,99,235,.04);
}

/* Breadcrumb & badge */
.crumbs{
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
}

.badge{
  display: inline-block;
  padding: 6px 10px;
  border-radius: 9999px;
  border: 1px solid rgba(37,99,235,.22);
  background: rgba(37,99,235,.08);
  color: rgba(37,99,235,.92);
  font-weight: 800;
  font-size: 12px;
}

/* Reduced motion */
@media (prefers-reduced-motion: reduce){
  .btn, .imgbox img{ transition: none !important; }
}


    /* loading állapot a gombon */
    .btn.loading{opacity:.75;pointer-events:none}
  </style>
</head>
<body>
  <!-- NAV -->
  <div class="nav">
    <div class="container row">
      <div class="brand">
        <div class="logo">RP</div>
        <div><div>Raktár Pro</div><small style="color:#6b7280">Termék</small></div>
      </div>
      <div class="right">
        <a class="btn outline" href="index.php">← Vissza</a>
        <a class="btn outline" href="/raktar_pro/kosar.php">🛒 Kosár</a>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="crumbs">
      Kategória: <?php echo h($termek['kategoria'] ?: 'N/A'); ?>
      • Cikkszám: <?php echo h($termek['cikkszam']); ?>
    </div>

    <div class="wrap">
      <div class="card">
        <div class="imgbox">
          <?php if (!empty($termek['kep_url'])): ?>
            <img src="<?php echo h($termek['kep_url']); ?>" alt="<?php echo h($termek['nev']); ?>">
          <?php else: ?>
            <div style="font-weight:900;color:#1f2937"><?php echo h($termek['cikkszam']); ?></div>
          <?php endif; ?>
        </div>
      </div>

      <div class="card">
        <div class="title"><?php echo h($termek['nev']); ?></div>
        <div class="meta"><?php echo h($termek['kategoria'] ?: ''); ?></div>
        <div class="meta"><?php echo nl2br(h($termek['leiras'] ?: '')); ?></div>

        <div class="price" style="display:flex;align-items:center;gap:10px">
          <?php echo number_format((float)$termek['egysegar'], 0, '', ' '); ?> Ft

        <?php if ($available_total <= 0): ?>
  <span class="badge" style="background:#fee2e2;color:#991b1b;border:1px solid #fecaca">Nincs készleten</span>
<?php else: ?>
  <span class="badge" style="background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0">
    Készleten: <?php echo (int)$available_total; ?> db
  </span>
<?php endif; ?>
    
        </div>

        <!-- Kosárba -->
        <form method="post" action="/raktar_pro/add_to_cart.php" class="add-to-cart-form"
              style="margin-top:14px;display:flex;gap:10px;align-items:center">
          <?php if ($available_total > 0): ?>
            <div class="qty">
              <input type="number" name="qty" value="1" min="1" max="<?php echo (int)$available_total; ?>" />
            </div>
            <input type="hidden" name="termek_id" value="<?php echo (int)$termek['id']; ?>">
            <button class="btn" type="submit">🛒 Kosárba</button>
          <?php else: ?>
            <button class="btn" type="button" disabled style="opacity:.6;cursor:not-allowed">Nincs készleten</button>
          <?php endif; ?>
        </form>

        <?php if (!empty($keszletek)): ?>
          <?php
            // csak azokat mutassuk, ahol tényleg van elérhető
            $keszletek_szurt = array_values(array_filter($keszletek, fn($x) => (int)$x['mennyiseg'] > 0));
          ?>
          <?php if (!empty($keszletek_szurt)): ?>
            <div style="margin-top:18px">
              <div style="font-weight:800;margin-bottom:6px">Készlet elérhetőség</div>
              <table class="table">
                <thead><tr><th>Raktár</th><th>Hely</th><th>Mennyiség</th></tr></thead>
                <tbody>
                  <?php foreach ($keszletek_szurt as $k): ?>
                    <tr>
                      <td><?php echo h($k['raktar']); ?></td>
                      <td><?php echo h($k['hely']); ?></td>
                      <td><?php echo (int)$k['mennyiseg']; ?> db</td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        <?php endif; ?>

      </div>
    </div>
  </div>

  <!-- toast script -->
  <script src="/raktar_pro/assets/js/toast.js"></script>

  <!-- Kosárba rakás ugyanúgy, mint a főoldalon -->
  <script>
  document.querySelectorAll('.add-to-cart-form').forEach(form => {
    form.addEventListener('submit', async function(e) {
      e.preventDefault();

      const formData = new FormData(this);
      const btn = this.querySelector('button[type="submit"]');
      const original = btn ? btn.innerHTML : '';

      if (btn) { btn.disabled = true; btn.classList.add('loading'); }

      try {
        const res = await fetch('/raktar_pro/add_to_cart.php', {
          method: 'POST',
          body: formData,
          headers: {
            'Accept': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
          }
        });

        const data = await res.json().catch(() => null);

        if (!res.ok || !data || data.success !== true) {
          const msg = (data && (data.error || data.message)) ? (data.error || data.message) : 'Hiba történt';
          throw new Error(msg);
        }

        window.toast?.success?.('Termék hozzáadva a kosárhoz! 🛒');

        if (btn) {
          btn.innerHTML = '✓ Hozzáadva';
          setTimeout(() => {
            btn.innerHTML = original;
            btn.disabled = false;
          }, 1200);
        }

      } catch (err) {
        window.toast?.error?.(err.message || 'Hiba történt');
        if (btn) { btn.innerHTML = original; btn.disabled = false; }
      } finally {
        if (btn) btn.classList.remove('loading');
      }
    });
  });
  </script>
</body>
</html>
