<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/cart_utils.php';

if (session_status() !== PHP_SESSION_ACTIVE) session_start();

// csak POST-tal engedjük (ne lehessen csak linkből kiüríteni)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: /raktar_pro/kosar.php');
  exit;
}

// ürítés
cart_clear();

// opcionális üzenet (ha akarsz)
$_SESSION['flash_success'] = 'A kosár kiürítve.';

header('Location: /raktar_pro/kosar.php');
exit;
