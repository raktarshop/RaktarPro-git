<?php
require_once __DIR__ . '/_init.php'; // admin ellenőrzés, $mysqli, h()

// --- Szűrők
$st   = trim($_GET['statusz'] ?? ''); // uj|feldolgozas|kiszallitva|teljesitve|torolve|''(mind)
$q    = trim($_GET['q'] ?? '');       // id, név, email keresés
$from = trim($_GET['from'] ?? '');    // 'YYYY-MM-DD'
$to   = trim($_GET['to'] ?? '');      // 'YYYY-MM-DD'

// Státuszok (értékek a DB-ben)
$statuses = [
  'uj'          => 'Új',
  'feldolgozas' => 'Feldolgozás',
  'kiszallitva' => 'Kiszállítva',
  'teljesitve'  => 'Teljesítve',
  'torolve'     => 'Törölve'
];

// Dátum validálás (ha valaki direkt rossz GET-et ad)
$fromOk = ($from !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $from));
$toOk   = ($to   !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $to));

$where  = "WHERE 1=1";
$params = [];
$types  = "";

// --- Státusz szűrés
if ($st !== '') {
  $where   .= " AND o.status = ?";
  $params[] = $st;
  $types   .= "s";
}

// --- Keresés (id pontos vagy name/email LIKE)
if ($q !== '') {
  if (ctype_digit($q)) {
    $where   .= " AND (o.id = ? OR o.name LIKE CONCAT('%', ?, '%') OR o.email LIKE CONCAT('%', ?, '%'))";
    $params[] = (int)$q; $types .= "i";
    $params[] = $q;      $types .= "s";
    $params[] = $q;      $types .= "s";
  } else {
    $where   .= " AND (o.name LIKE CONCAT('%', ?, '%') OR o.email LIKE CONCAT('%', ?, '%'))";
    $params[] = $q; $types .= "s";
    $params[] = $q; $types .= "s";
  }
}

// --- Dátum szűrés (created_at)
if ($fromOk) {
  $where   .= " AND DATE(o.created_at) >= ?";
  $params[] = $from;
  $types   .= "s";
}
if ($toOk) {
  $where   .= " AND DATE(o.created_at) <= ?";
  $params[] = $to;
  $types   .= "s";
}

// --- Lekérdezés (utolsó 200)
$sql = "
  SELECT
    o.id,
    o.user_id,
    o.name,
    o.email,
    o.address,
    o.payment_method,
    o.gross_total,
    o.status,
    o.created_at
  FROM orders o
  $where
  ORDER BY o.created_at DESC
  LIMIT 200
";

$rows = [];
$errorMsg = "";

try {
  $stmt = $mysqli->prepare($sql);
  if (!$stmt) {
    throw new mysqli_sql_exception("Prepare failed: " . $mysqli->error);
  }

  if ($params) {
    $stmt->bind_param($types, ...$params);
  }

  $stmt->execute();
  $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
  $stmt->close();

} catch (mysqli_sql_exception $e) {
  if (strpos($e->getMessage(), "doesn't exist") !== false) {
    $errorMsg = "Hiányzik az <b>orders</b> tábla az adatbázisból, vagy nem a jó adatbázist használja a kapcsolat.";
  } else {
    $errorMsg = "Adatbázis hiba: " . h($e->getMessage());
  }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <title>Admin – Rendelések</title>
  <link rel="stylesheet" href="style_admin.css">
  <style>
    .filters{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}
    .filters input,.filters select{padding:10px;border:1px solid #e5e7eb;border-radius:10px}
    .status-badge{display:inline-block;padding:4px 8px;border-radius:9999px;border:1px solid #e5e7eb;background:#f9fafb}
    .table{width:100%;border-collapse:collapse}
    .table th,.table td{padding:10px;border-bottom:1px solid #e5e7eb;text-align:left;vertical-align:top}
    .row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
    .btn{display:inline-flex;gap:8px;align-items:center;background:#111827;color:#fff;border:none;border-radius:10px;padding:10px 12px;text-decoration:none;cursor:pointer}
    .btn.outline{background:#fff;color:#111827;border:1px solid #111827}
    .container{width:min(1200px,94vw);margin:20px auto}
    .card{background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:16px;margin-bottom:16px}
    .alert{background:#fff7ed;border:1px solid #fdba74;color:#9a3412;padding:12px;border-radius:12px;margin:12px 0}
    .muted{color:#6b7280}
    .chip{display:inline-block;padding:3px 8px;border-radius:9999px;border:1px solid #e5e7eb;background:#fff}
  </style>
</head>
<body>
<div class="container">
  <div class="card">
    <div class="row" style="justify-content:space-between">
      <h1>🧾 Rendelések</h1>
      <div class="row">
        <a class="btn outline" href="/raktar_pro/admin/index.php">← Dashboard</a>
        <a class="btn outline" href="/raktar_pro/index.php">🏪 Bolt</a>
      </div>
    </div>

    <?php if ($errorMsg): ?>
      <div class="alert"><?php echo $errorMsg; ?></div>
    <?php endif; ?>

    <form class="filters" method="get">
      <select name="statusz">
        <option value="">Minden státusz</option>
        <?php foreach ($statuses as $k=>$v): ?>
          <option value="<?php echo h($k); ?>" <?php if($k===$st) echo 'selected'; ?>>
            <?php echo h($v); ?>
          </option>
        <?php endforeach; ?>
      </select>

      <input type="date" name="from" value="<?php echo h($from); ?>">
      <input type="date" name="to"   value="<?php echo h($to); ?>">

      <input type="text" name="q" placeholder="Keresés: #ID / név / e-mail" value="<?php echo h($q); ?>">

      <button class="btn" type="submit">Szűrés</button>
      <a class="btn outline" href="rendelesek.php">Szűrők törlése</a>
    </form>

    <table class="table">
      <thead>
        <tr>
          <th>#</th>
          <th>Vevő</th>
          <th>E-mail</th>
          <th>Cím</th>
          <th>Fizetés</th>
          <th>Összeg</th>
          <th>Státusz</th>
          <th>Dátum</th>
          <th>Művelet</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td>#<?php echo (int)$r['id']; ?></td>
            <td>
              <?php echo h($r['name']); ?>
              <?php if (!empty($r['user_id'])): ?>
                <span class="chip">user_id: <?php echo (int)$r['user_id']; ?></span>
              <?php endif; ?>
            </td>
            <td><?php echo h($r['email']); ?></td>
            <td><?php echo h($r['address']); ?></td>
            <td><?php echo h($r['payment_method']); ?></td>
            <td><?php echo number_format((int)$r['gross_total'], 0, '', ' '); ?> Ft</td>
            <td>
              <span class="status-badge">
                <?php echo h($statuses[$r['status']] ?? $r['status']); ?>
              </span>
            </td>
            <td><?php echo h($r['created_at']); ?></td>
            <td>
              <a class="btn outline" href="rendeles_reszletek.php?id=<?php echo (int)$r['id']; ?>">Részletek</a>
            </td>
          </tr>
        <?php endforeach; ?>

        <?php if (!$errorMsg && empty($rows)): ?>
          <tr>
            <td colspan="9" class="muted" style="text-align:center">Nincs találat a szűrésre.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
</body>
</html>
