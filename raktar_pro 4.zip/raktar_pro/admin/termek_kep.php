<?php
require_once __DIR__ . '/_init.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
  exit('Hiányzó termék azonosító.');
}

/* ===============================
   Termék lekérése
================================ */
$stmt = $mysqli->prepare("
  SELECT 
    id,
    name AS nev,
    sku AS cikkszam,
    image_url AS kep_url
  FROM products
  WHERE id = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$prod = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$prod) {
  exit('Termék nem található.');
}

$msg = '';
$err = '';

/* ===============================
   Feldolgozás
================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

  $external = trim($_POST['external_url'] ?? '');

  /* ========= KÉP TÖRLÉSE ========= */
  if (isset($_POST['delete']) && $_POST['delete'] === '1') {


    if (
      !empty($prod['kep_url']) &&
      str_starts_with($prod['kep_url'], '/raktar_pro/uploads/termekek/')
    ) {
      $abs = __DIR__ . '/../uploads/termekek/' . basename($prod['kep_url']);
      if (is_file($abs)) {
        @unlink($abs);
      }
    }

    $u = $mysqli->prepare("
      UPDATE products 
      SET image_url = NULL, updated_at = NOW()
      WHERE id = ?
    ");
    $u->bind_param("i", $id);
    $u->execute();
    $u->close();

    $prod['kep_url'] = null;
    $msg = 'Kép törölve.';

  /* ========= FÁJL FELTÖLTÉS ========= */
  } elseif (!empty($_FILES['kep']['name'])) {

    $f = $_FILES['kep'];

    if ($f['error'] !== UPLOAD_ERR_OK) {
      $err = 'Feltöltési hiba (kód: ' . $f['error'] . ').';
    } else {

      $fi = new finfo(FILEINFO_MIME_TYPE);
      $mime = $fi->file($f['tmp_name']);

      $allowed = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif'
      ];

      if (!isset($allowed[$mime])) {
        $err = 'Csak JPG, PNG, WEBP vagy GIF tölthető fel.';
      } elseif ($f['size'] > 5 * 1024 * 1024) {
        $err = 'A fájl túl nagy (max 5 MB).';
      } else {

        $dir = __DIR__ . '/../uploads/termekek';
        if (!is_dir($dir)) {
          @mkdir($dir, 0775, true);
        }

        $ext   = $allowed[$mime];
        $fname = $id . '_' . time() . '.' . $ext;

        $targetAbs = $dir . '/' . $fname;
        $targetUrl = '/raktar_pro/uploads/termekek/' . $fname;

        if (!move_uploaded_file($f['tmp_name'], $targetAbs)) {
          $err = 'A fájlt nem sikerült véglegesen menteni.';
        } else {

          @chmod($targetAbs, 0664);

          $u = $mysqli->prepare("
            UPDATE products 
            SET image_url = ?, updated_at = NOW()
            WHERE id = ?
          ");
          $u->bind_param("si", $targetUrl, $id);
          $u->execute();
          $u->close();

          $prod['kep_url'] = $targetUrl;
          $msg = 'Kép feltöltve és mentve.';
        }
      }
    }

  /* ========= KÜLSŐ URL ========= */
  } elseif ($external !== '') {

    $u = $mysqli->prepare("
      UPDATE products 
      SET image_url = ?, updated_at = NOW()
      WHERE id = ?
    ");
    $u->bind_param("si", $external, $id);
    $u->execute();
    $u->close();

    $prod['kep_url'] = $external;
    $msg = 'Külső kép URL mentve.';

  } else {
    $err = 'Nem érkezett fájl vagy URL.';
  }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <title>Admin – Kép feltöltés</title>
  <link rel="stylesheet" href="style_admin.css">
</head>
<body>

<div class="container">
  <div class="card">

    <h1>
      🖼️ Kép feltöltés –
      <?php echo h($prod['nev']); ?>
      (<?php echo h($prod['cikkszam']); ?>)
    </h1>

    <div class="row" style="justify-content:space-between;margin-bottom:10px">
      <a class="btn outline" href="termekek.php">← Vissza a termékekhez</a>
      <a class="btn outline"
         href="/raktar_pro/termek.php?id=<?php echo (int)$prod['id']; ?>"
         target="_blank">
        Termék megnyitása
      </a>
    </div>

    <?php if ($msg): ?>
      <div class="notice"><?php echo h($msg); ?></div>
    <?php endif; ?>

    <?php if ($err): ?>
      <div class="error"><?php echo h($err); ?></div>
    <?php endif; ?>

    <div class="row">

      <!-- Jelenlegi kép -->
      <div class="card" style="flex:1;min-width:280px">
        <h3>Jelenlegi kép</h3>

        <?php if (!empty($prod['kep_url'])): ?>
          <img
            src="<?php echo h($prod['kep_url']); ?>"
            style="max-width:100%;border:1px solid #e5e7eb;border-radius:10px"
            alt=""
          >

          <form method="post" style="margin-top:10px">
            <input type="hidden" name="delete" value="1">
            <button class="btn outline" type="submit">
              Kép törlése
            </button>
          </form>
        <?php else: ?>
          <div class="badge">Ehhez a termékhez még nincs kép.</div>
        <?php endif; ?>
      </div>

      <!-- Feltöltés -->
      <div class="card" style="flex:1;min-width:280px">
        <h3>Fájl feltöltése</h3>
        <form method="post" enctype="multipart/form-data">
          <input type="file" name="kep" accept="image/*" required>
          <div style="margin-top:8px">
            <button class="btn" type="submit">Feltöltés</button>
          </div>
          <div class="badge" style="margin-top:8px">
            JPG / PNG / WEBP / GIF – max 5 MB
          </div>
        </form>
      </div>

      <!-- Külső URL -->
      <div class="card" style="flex:1;min-width:280px">
        <h3>Külső kép URL</h3>
        <form method="post">
          <input type="text"
                 name="external_url"
                 placeholder="https://pelda.hu/kep.jpg">
          <div style="margin-top:8px">
            <button class="btn" type="submit">URL mentése</button>
          </div>
        </form>
      </div>

    </div>

  </div>
</div>

</body>
</html>
