<?php
require_once __DIR__ . '/_init.php'; // admin check, $mysqli, h()

$product_id = (int)($_GET['product_id'] ?? 0);
if ($product_id <= 0) exit('Hibás termék azonosító.');

if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
$csrf = $_SESSION['csrf'];

$msg = $err = '';

// Termék név
$pst = $mysqli->prepare("SELECT id, name, sku FROM products WHERE id = ? LIMIT 1");
$pst->bind_param("i", $product_id);
$pst->execute();
$product = $pst->get_result()->fetch_assoc();
$pst->close();
if (!$product) exit('Termék nem található.');

// POST: mentés
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!hash_equals($csrf, $_POST['csrf'] ?? '')) {
    $err = "Érvénytelen kérés (CSRF).";
  } else {
    // Tömbök
    $stock_id = $_POST['stock_id'] ?? [];
    $qty      = $_POST['quantity'] ?? [];
    $res      = $_POST['reserved_quantity'] ?? [];

    try {
      $mysqli->begin_transaction();

      $u = $mysqli->prepare("UPDATE stock SET quantity = ?, reserved_quantity = ? WHERE id = ? AND product_id = ?");
      for ($i=0; $i<count($stock_id); $i++) {
        $sid = (int)$stock_id[$i];
$q = max(0, (int)($qty[$i] ?? 0));
$r = max(0, (int)($res[$i] ?? 0));
if ($r > $q) $r = $q; // reserved nem lehet több mint a készlet
        $u->bind_param("iiii", $q, $r, $sid, $product_id);
        $u->execute();
      }
      $u->close();

      $mysqli->commit();
      $msg = "Készlet mentve.";
    } catch (Throwable $e) {
      $mysqli->rollback();
      $err = "Mentési hiba: " . h($e->getMessage());
    }
  }
}

// Aktuális készlet sorok
$rows = [];
try {
  $q = $mysqli->prepare("
    SELECT
      s.id AS stock_id,
      w.name AS warehouse,
      l.code AS location_code,
      s.quantity,
      s.reserved_quantity
    FROM stock s
    JOIN locations l ON l.id = s.location_id
    JOIN warehouses w ON w.id = l.warehouse_id
    WHERE s.product_id = ?
    ORDER BY w.name, l.code
  ");
  $q->bind_param("i", $product_id);
  $q->execute();
  $rows = $q->get_result()->fetch_all(MYSQLI_ASSOC);
  $q->close();
} catch (Throwable $e) {
  $err = $err ?: "Lekérdezési hiba: " . h($e->getMessage());
}

// Összes elérhető
$totalAvail = 0;
foreach ($rows as $r) {
  $totalAvail += max(0, (int)$r['quantity'] - (int)$r['reserved_quantity']);
}
?>
<!doctype html>
<html lang="hu">
<head>
  <meta charset="utf-8">
  <title>Készlet szerkesztés – Admin</title>
  <link rel="stylesheet" href="style_admin.css">
  <style>
    .container{width:min(1100px,94vw);margin:20px auto}
    .card{background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:16px;margin-bottom:16px}
    .row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
    .btn{display:inline-flex;gap:8px;align-items:center;background:#111827;color:#fff;border:none;border-radius:10px;padding:10px 12px;text-decoration:none;cursor:pointer}
    .btn.outline{background:#fff;color:#111827;border:1px solid #111827}
    .table{width:100%;border-collapse:collapse}
    .table th,.table td{padding:10px;border-bottom:1px solid #e5e7eb;text-align:left}
    input[type="number"]{width:100px;padding:8px;border:1px solid #e5e7eb;border-radius:10px}
    .note{padding:10px 12px;border-radius:10px;margin-bottom:12px}
    .notice{background:#ecfdf5;border:1px solid #a7f3d0;color:#065f46}
    .error{background:#fef2f2;border:1px solid #fecaca;color:#7f1d1d}
    .badge{display:inline-block;padding:4px 10px;border-radius:9999px;border:1px solid #e5e7eb;background:#f9fafb}
  </style>
</head>
<body>
<div class="container">

  <div class="card">
    <div class="row" style="justify-content:space-between">
      <div>
        <h1 style="margin:0">📦 Készlet szerkesztés</h1>
        <div style="color:#6b7280;margin-top:6px">
          Termék: <strong><?php echo h($product['name']); ?></strong> • SKU: <?php echo h($product['sku']); ?>
          • <span class="badge">Elérhető összesen: <?php echo (int)$totalAvail; ?> db</span>
        </div>
      </div>
      <div class="row">
        <a class="btn outline" href="/raktar_pro/admin/termek.php?id=<?php echo (int)$product_id; ?>">← Termék</a>
        <a class="btn outline" href="/raktar_pro/admin/termekek.php">Termékek</a>
      </div>
    </div>

    <?php if ($msg): ?><div class="note notice"><?php echo h($msg); ?></div><?php endif; ?>
    <?php if ($err): ?><div class="note error"><?php echo h($err); ?></div><?php endif; ?>

    <?php if (empty($rows)): ?>
      <div style="color:#6b7280">Nincs stock sor ehhez a termékhez. (A stock táblában nincs hozzárendelt location.)</div>
    <?php else: ?>
      <form method="post">
        <input type="hidden" name="csrf" value="<?php echo h($csrf); ?>">

        <table class="table">
          <thead>
            <tr>
              <th>Raktár</th>
              <th>Hely</th>
              <th>Quantity</th>
              <th>Reserved</th>
              <th>Elérhető</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($rows as $i => $r): 
              $avail = max(0, (int)$r['quantity'] - (int)$r['reserved_quantity']);
            ?>
              <tr>
                <td><?php echo h($r['warehouse']); ?></td>
                <td><?php echo h($r['location_code']); ?></td>

                <td>
                  <input type="hidden" name="stock_id[]" value="<?php echo (int)$r['stock_id']; ?>">
                  <input type="number" name="quantity[]" min="0" value="<?php echo (int)$r['quantity']; ?>">
                </td>

                <td>
                  <input type="number" name="reserved_quantity[]" min="0" value="<?php echo (int)$r['reserved_quantity']; ?>">
                </td>

                <td><strong><?php echo $avail; ?></strong></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

        <div class="row" style="margin-top:12px;justify-content:flex-end">
          <button class="btn" type="submit">💾 Mentés</button>
        </div>
      </form>
    <?php endif; ?>
  </div>

</div>
</body>
</html>
