<?php
// Admin guard + részletes debug, hogy miért dob vissza
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../includes/auth_jwt.php';

// Kapcsold fel 1 teszt erejéig true-ra, hogy láss MINDENT
const DEBUG_ADMIN_AUTH = true;

if (!function_exists('dump_exit')) {
  function dump_exit($data, $title='DEBUG') {
    header('Content-Type: text/plain; charset=utf-8');
    echo "=== {$title} ===\n";
    if (is_array($data) || is_object($data)) { print_r($data); }
    else { var_dump($data); }
    exit;
  }
}

if (DEBUG_ADMIN_AUTH) {
  // 1) Böngészőből érkező cookie-k
  $dbg = [];
  $dbg['REQUEST_URI'] = $_SERVER['REQUEST_URI'] ?? '';
  $dbg['COOKIES_FROM_BROWSER'] = $_COOKIE;

  // 2) Access token ellenőrzés
  $token = read_access_token_from_request();
  $dbg['ACCESS_TOKEN_PRESENT'] = $token ? (strlen($token) . ' bytes') : 'NO';
  $decoded = verify_access_token($token);
  $dbg['ACCESS_TOKEN_DECODED'] = $decoded ? (array)$decoded : 'INVALID/EXPIRED';

  // 3) Ha nincs/lejárt: próbálunk refresh-sel új access-t adni
  if (!$decoded) {
    $dbg['TRY_REFRESH'] = 'YES';
    $decoded = try_refresh_and_issue($mysqli);
    $dbg['AFTER_REFRESH_DECODED'] = $decoded ? (array)$decoded : 'REFRESH_FAILED';
    // Cookie-k a szerver által most kiküldve
    $dbg['HEADERS_LIST'] = headers_list();
  } else {
    $dbg['TRY_REFRESH'] = 'NO';
  }

  // 4) Ha még mindig nincs érvényes token, mutassuk meg és ne loopoljon
  if (!$decoded) {
    $dbg['WHAT_TO_FIX'] =
      "Nincs érvényes access, és a refresh sem működött.\n".
      "- Nézd meg a DevTools > Application > Cookies alatt: van-e access és rp_refresh? Path = '/'\n".
      "- Bejelentkezés után azonnal legyen Set-Cookie mindkettőre.\n".
      "- config.php: COOKIE_PATH='/' legyen.\n";
    dump_exit($dbg, 'ADMIN AUTH DEBUG – NOT AUTHENTICATED');
  }

  // 5) Szerepkör vizsgálat
  $role = $decoded->role ?? 'user';
  $dbg['ROLE'] = $role;
  if ($role !== 'admin') {
    $dbg['WHAT_TO_FIX'] = "A token role = '{$role}', de admin kell. Nézd meg a felhasználó szerepkörét a DB-ben.";
    dump_exit($dbg, 'ADMIN AUTH DEBUG – FORBIDDEN (NOT ADMIN)');
  }

  // Ha idáig eljutottunk, minden oké – készítünk egy $auth objektumot
  $GLOBALS['auth'] = (object)[
    'user_id' => (int)$decoded->sub,
    'role'    => (string)$role,
    'email'   => (string)($decoded->email ?? '')
  ];
} else {
  // Normál guard (debug nélkül)
  $GLOBALS['auth'] = require_auth($mysqli, ['admin']);
}
