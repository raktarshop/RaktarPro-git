(() => {
  const apiUrl = '/raktar_pro/api/kosar.php';

  const fab = document.getElementById('cartFab');
  const popup = document.getElementById('cartPopup');
  const closeBtn = document.getElementById('cartClose');
  const itemsEl = document.getElementById('cartItems');
  const totalEl = document.getElementById('cartTotal');
  const badgeFabEl = document.getElementById('cartCount');

  // navbar badge (ha van)
  const navbarBadgeEl = document.querySelector('.navbar__cart .badge');

  if (!fab || !popup || !itemsEl || !totalEl || !badgeFabEl) {
    // Ha ezen az oldalon nincs FAB markup, ne dobjon hibát
    return;
  }

  function fmtFt(n) {
    const num = Number(n || 0);
    return num.toLocaleString('hu-HU') + ' Ft';
  }

  function setCounts(count) {
    const c = Number(count || 0);
    badgeFabEl.textContent = String(c);

    // navbar badge frissítése
    if (navbarBadgeEl) {
      navbarBadgeEl.textContent = String(c);
      navbarBadgeEl.style.display = c > 0 ? 'inline-flex' : 'none';
    }

    // FAB elrejtése, ha üres (ha akarod, kikapcsolhatod)
    fab.style.display = 'flex';
  }

  function renderItems(items) {
    if (!Array.isArray(items) || items.length === 0) {
      itemsEl.innerHTML = `<div class="cart-empty">A kosarad üres.</div>`;
      return;
    }

    const html = items.map(it => {
      const name = it.nev ?? '';
      const qty = Number(it.db ?? 0);
      const price = fmtFt(it.ar ?? 0);
      const subtotal = fmtFt(it.ossz ?? 0);

      const img = it.kep
        ? `<img src="${escapeHtmlAttr(it.kep)}" alt="${escapeHtmlAttr(name)}" style="width:44px;height:44px;object-fit:cover;border-radius:10px;border:1px solid var(--color-border);" />`
        : `<div style="width:44px;height:44px;border-radius:10px;border:1px solid var(--color-border);display:flex;align-items:center;justify-content:center;color:var(--color-muted);font-weight:700;">RP</div>`;

      return `
        <div class="cart-row" style="display:flex;gap:10px;align-items:center;padding:10px 0;border-bottom:1px solid var(--color-border);">
          ${img}
          <div style="flex:1;min-width:0;">
            <div style="font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
              ${escapeHtml(name)}
            </div>
            <div style="color:var(--color-text-light);font-size:0.9rem;">
              ${qty} × ${price}
            </div>
          </div>
          <div style="font-weight:900;color:var(--color-primary);white-space:nowrap;">
            ${subtotal}
          </div>
        </div>
      `;
    }).join('');

    itemsEl.innerHTML = html;
  }

  function escapeHtml(s) {
    return String(s ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }
  function escapeHtmlAttr(s) {
    return escapeHtml(s).replaceAll('`', '&#096;');
  }

  async function loadCart() {
    try {
      const res = await fetch(apiUrl, {
        method: 'GET',
        headers: { 'Accept': 'application/json' },
        credentials: 'same-origin'
      });

      const data = await res.json().catch(() => null);
      if (!res.ok || !data || data.success !== true) {
        throw new Error((data && (data.error || data.message)) ? (data.error || data.message) : 'Nem sikerült betölteni a kosarat');
      }

      setCounts(data.count);
      renderItems(data.items);
      totalEl.textContent = fmtFt(data.total);

      // accessibility state
      popup.setAttribute('aria-hidden', 'true');
      fab.setAttribute('aria-expanded', 'false');
    } catch (e) {
      // ha hiba van, ne álljon meg az oldal
      setCounts(0);
      itemsEl.innerHTML = `<div class="cart-empty">Nem sikerült betölteni a kosarat.</div>`;
      totalEl.textContent = fmtFt(0);
    }
  }

  function openPopup() {
    popup.classList.add('open');
    popup.setAttribute('aria-hidden', 'false');
    fab.setAttribute('aria-expanded', 'true');
  }

  function closePopup() {
    popup.classList.remove('open');
    popup.setAttribute('aria-hidden', 'true');
    fab.setAttribute('aria-expanded', 'false');
  }

  // Gombok
  fab.addEventListener('click', () => {
    const isOpen = popup.classList.contains('open');
    if (isOpen) closePopup();
    else openPopup();
  });

  if (closeBtn) closeBtn.addEventListener('click', closePopup);

  // Kattintás a popup-on kívül bezárja (ha van overlay-szerű UX, itt egyszerű)
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closePopup();
  });

  // Események: ha kosárba tettél, frissítsünk
  window.addEventListener('cart:add', (e) => {
    // Ha a detail-ben megjött count/total, azonnal frissítjük, utána betöltjük a listát is
    if (e.detail && typeof e.detail.count === 'number') setCounts(e.detail.count);
    if (e.detail && typeof e.detail.total === 'number') totalEl.textContent = fmtFt(e.detail.total);
    loadCart();
  });

  // első betöltéskor is töltsük be
  loadCart();
})();
