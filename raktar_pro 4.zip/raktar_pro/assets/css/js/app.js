async function updateCartBadge() {
  try {
    const res = await fetch('api/cart_count.php', { credentials: 'same-origin' });
    const data = await res.json();

    const badge = document.getElementById('cartBadge');
    if (!badge) return;

    const n = Number(data.count || 0);

    if (n > 0) {
      badge.textContent = n;
      badge.style.display = 'inline-block';
    } else {
      badge.textContent = '0';
      badge.style.display = 'none';
    }
  } catch (e) {
    // opcionális: console.log(e);
  }
}

document.addEventListener('DOMContentLoaded', updateCartBadge);
