<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/cart_utils.php';

$q    = trim($_GET['q'] ?? '');
$kat  = intval($_GET['kat'] ?? 0);
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 12;
$offset = ($page - 1) * $limit;

// Kategóriák
$kats = [];
if ($res = $mysqli->query("SELECT id, name AS nev FROM categories ORDER BY nev")) {
  while ($row = $res->fetch_assoc()) $kats[] = $row;
  $res->free();
}

// Szűrés
$where = "WHERE 1=1";
$params = [];
$types = '';

if ($q !== '') {
  $where .= " AND (t.name LIKE CONCAT('%', ?, '%')
               OR t.description LIKE CONCAT('%', ?, '%')
               OR t.sku LIKE CONCAT('%', ?, '%'))";
  $params = [$q, $q, $q];
  $types = 'sss';
}

if ($kat > 0) {
  $where .= " AND t.category_id = ?";
  $params[] = $kat;
  $types .= 'i';
}

/**
 * Találatok száma – csak készletesek számolása
 * (a készletet stockból számoljuk: SUM(quantity - reserved_quantity))
 */
$countSql = "
  SELECT COUNT(*) AS c FROM (
    SELECT t.id
    FROM products t
    LEFT JOIN stock s ON s.product_id = t.id
    $where
    GROUP BY t.id
    HAVING GREATEST(COALESCE(SUM(s.quantity - s.reserved_quantity), 0), 0) > 0
  ) x
";

$stmt = $mysqli->prepare($countSql);
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
$stmt->close();

/**
 * Termékek – készlet STOCK táblából számolva (reserved levonva)
 * + csak készletes termékeket mutatunk: HAVING available > 0
 */
$query = "
  SELECT
    t.id,
    t.sku          AS cikkszam,
    t.name         AS nev,
    t.description  AS leiras,
    t.unit_price   AS egysegar,
    t.image_url    AS kep_url,
    k.name         AS kategoria,
    GREATEST(COALESCE(SUM(s.quantity - s.reserved_quantity), 0), 0) AS available
  FROM products t
  LEFT JOIN categories k ON k.id = t.category_id
  LEFT JOIN stock s ON s.product_id = t.id
  $where
  GROUP BY
    t.id, t.sku, t.name, t.description, t.unit_price, t.image_url, k.name
  HAVING available > 0
  ORDER BY t.id DESC
  LIMIT ? OFFSET ?
";

if ($params) {
  $stmt = $mysqli->prepare($query);
  $stmt->bind_param($types . 'ii', ...array_merge($params, [$limit, $offset]));
} else {
  $stmt = $mysqli->prepare($query);
  $stmt->bind_param('ii', $limit, $offset);
}

$stmt->execute();
$products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$pages = max(1, (int)ceil($total / $limit));
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
$cartCount = function_exists('cart_count') ? cart_count() : 0;
?>

<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Raktár Pro – Főoldal | Professzionális raktári megoldások</title>
  <meta name="description" content="Raktár Pro - 1000+ termék raktáron. Ipari eszközök, irodai kellékek, gyors szállítás.">
  
  <!-- CSS -->
  <link rel="stylesheet" href="/raktar_pro/assets/css/variables.css">
  <link rel="stylesheet" href="/raktar_pro/assets/css/base.css">
  <link rel="stylesheet" href="/raktar_pro/assets/css/components.css">
  <link rel="stylesheet" href="/raktar_pro/assets/css/layout.css">
  <link rel="stylesheet" href="/raktar_pro/assets/css/toast.css">
  <link rel="stylesheet" href="/raktar_pro/assets/cart-fab.css">
  
  <style>
/* ===== Modern Product Card (blue vibe kept) ===== */

/* Ha nincs primary változód, ez fallback */
:root{
  --primary: var(--color-primary, #2563eb);
  --primary-600: var(--color-primary-600, #1d4ed8);
  --card-glow: color-mix(in srgb, var(--primary) 18%, transparent);
  --card-border: color-mix(in srgb, var(--primary) 18%, var(--color-border));
}

.product-card{
  background: var(--color-card);
  border: 1px solid var(--card-border);
  border-radius: calc(var(--radius-lg) + 2px);
  overflow: hidden;
  display: flex;
  flex-direction: column;

  /* modernebb “depth” */
  box-shadow:
    0 1px 0 rgba(255,255,255,.06) inset,
    0 10px 24px rgba(0,0,0,.08);
  transform: translateZ(0);
  transition: transform .22s ease, box-shadow .22s ease, border-color .22s ease;
}

/* Kicsit “premium” hover: lift + blue glow */
.product-card:hover{
  transform: translateY(-6px);
  border-color: color-mix(in srgb, var(--primary) 35%, var(--color-border));
  box-shadow:
    0 1px 0 rgba(255,255,255,.08) inset,
    0 18px 40px rgba(0,0,0,.12),
    0 0 0 6px var(--card-glow);
}

/* Klikkelhető elemekhez: fókusz látható legyen */
.product-card:focus-within{
  border-color: color-mix(in srgb, var(--primary) 45%, var(--color-border));
  box-shadow:
    0 1px 0 rgba(255,255,255,.08) inset,
    0 18px 40px rgba(0,0,0,.12),
    0 0 0 6px color-mix(in srgb, var(--primary) 22%, transparent);
}

.product-card__image-wrapper{
  position: relative;
  height: 210px; /* picit magasabb = jobban “shop” hatás */
  background: var(--color-border-light);
  overflow: hidden;
}

/* Kép overlay: jobb olvashatóság + modern hangulat */
.product-card__image-wrapper::after{
  content: "";
  position: absolute;
  inset: 0;
  background:
    linear-gradient(180deg,
      rgba(0,0,0,0) 40%,
      rgba(0,0,0,.28) 100%),
    radial-gradient(900px 220px at 50% -20%,
      color-mix(in srgb, var(--primary) 22%, transparent),
      transparent 55%);
  pointer-events: none;
  opacity: .95;
}

.product-card__image{
  width: 100%;
  height: 100%;
  object-fit: cover;
  transform: scale(1.001);
  transition: transform .6s cubic-bezier(.2,.8,.2,1), filter .6s ease;
}

.product-card:hover .product-card__image{
  transform: scale(1.06);
  filter: saturate(1.04) contrast(1.02);
}

/* Placeholder modernebb, “skeleton” jelleg */
.product-card__placeholder{
  width: 100%;
  height: 100%;
  display: grid;
  place-items: center;
  color: var(--color-muted);
  font-weight: var(--font-weight-semibold);
  background:
    linear-gradient(110deg,
      color-mix(in srgb, var(--color-border-light) 70%, transparent) 10%,
      color-mix(in srgb, var(--primary) 10%, var(--color-border-light)) 35%,
      color-mix(in srgb, var(--color-border-light) 70%, transparent) 60%);
  background-size: 200% 100%;
  animation: shimmer 1.4s ease-in-out infinite;
}

@keyframes shimmer{
  0%{ background-position: 200% 0; }
  100%{ background-position: -200% 0; }
}

.product-card__body{
  padding: calc(var(--space-lg) + 2px);
  display: flex;
  flex-direction: column;
  gap: var(--space-sm);
  flex: 1;
}

/* Kategória = chip */
.product-card__category{
  align-self: flex-start;
  font-size: var(--font-size-xs);
  font-weight: var(--font-weight-semibold);
  letter-spacing: .06em;
  text-transform: uppercase;

  padding: 6px 10px;
  border-radius: 999px;
  border: 1px solid color-mix(in srgb, var(--primary) 22%, var(--color-border));
  background: color-mix(in srgb, var(--primary) 10%, var(--color-card));
  color: color-mix(in srgb, var(--primary) 70%, var(--color-muted));
}

.product-card__title{
  font-size: clamp(1.02rem, 1.1vw, 1.18rem);
  font-weight: var(--font-weight-extrabold);
  color: var(--color-text);
  line-height: var(--line-height-tight);
  margin: 0;

  /* 2 soros vágás: egységes kártyák */
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.product-card__description{
  font-size: var(--font-size-sm);
  color: var(--color-text-light);
  line-height: var(--line-height-normal);
  flex: 1;

  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.product-card__footer{
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: var(--space-md);
  margin-top: var(--space-md);
  padding-top: var(--space-md);
  border-top: 1px solid color-mix(in srgb, var(--color-border) 70%, transparent);
}

.product-card__price{
  display: flex;
  align-items: baseline;
  gap: 10px;
}

.product-card__price strong{
  font-size: clamp(1.15rem, 1.3vw, 1.35rem);
  font-weight: var(--font-weight-extrabold);
  color: var(--color-text);
}

/* Actions: kicsit “button bar” érzés */
.product-card__actions{
  display: flex;
  gap: var(--space-sm);
  margin-top: var(--space-md);
}

/* Ha a gombjaid class-olhatók, ez rásegít (nem kötelező) */
.product-card__actions .btn,
.product-card__actions button,
.product-card__actions a{
  border-radius: 12px;
  transition: transform .18s ease, box-shadow .18s ease, background-color .18s ease;
}

.product-card__actions .btn-primary,
.product-card__actions button.primary{
  background: linear-gradient(180deg, var(--primary), var(--primary-600));
  box-shadow: 0 10px 18px color-mix(in srgb, var(--primary) 22%, transparent);
}

.product-card__actions .btn:hover,
.product-card__actions button:hover,
.product-card__actions a:hover{
  transform: translateY(-1px);
}

/* Mozgáscsökkentés tiszteletben tartása */
@media (prefers-reduced-motion: reduce){
  .product-card,
  .product-card__image,
  .product-card__placeholder{
    transition: none !important;
    animation: none !important;
  }
}

  </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="container navbar__container">
    <!-- Brand -->
    <a href="/raktar_pro/index.php" class="navbar__brand">
      <div class="navbar__logo">RP</div>
      <div class="navbar__title">
        <span>Raktár Pro</span>
        <small>Professzionális raktári megoldások</small>
      </div>
    </a>

   <!-- Actions -->
    <div class="navbar__actions">
      <!-- Theme toggle -->
      <button id="themeToggle" class="navbar__icon-btn" aria-label="Téma váltása">
        🌙
      </button>

      <!-- Admin link (ha admin) -->
      <?php if (isset($_SESSION['szerepkor_id']) && (int)$_SESSION['szerepkor_id'] === 1): ?>
        <a href="/raktar_pro/admin/index.php" class="btn btn-sm">
          🛠️ Admin
        </a>
      <?php endif; ?>

      <!-- Kosár -->
<a href="/raktar_pro/kosar.php" class="navbar__cart">
  🛒
  <span class="badge badge-danger"
        style="<?= $cartCount > 0 ? '' : 'display:none' ?>">
    <?= (int)$cartCount ?>
  </span>
</a>


      <!-- Profil -->
      <a href="/raktar_pro/profil.php" class="navbar__avatar" title="<?= h($_SESSION['teljes_nev'] ?? 'Profil') ?>">
        <?= strtoupper(substr($_SESSION['teljes_nev'] ?? 'U', 0, 1)) ?>
      </a>
    </div>
  </div>
</nav>

<!-- HERO -->
<section class="hero">
  <div class="hero__container container">
    <h1>Profi raktári megoldások</h1>
    <p>
      Fedezze fel széleskörű termékpalettánkat az ipari eszközöktől az irodai kellékekig.<br>
      Több mint <strong>1000+</strong> termék raktáron, gyors szállítással.
    </p>
    <div class="hero__perks">
      <span class="hero__perk">⚙️ Legmagasabb minőség</span>
      <span class="hero__perk">⭐ Megbízható szolgáltatás</span>
      <span class="hero__perk">⚡ Azonnali raktári készlet</span>
    </div>
  </div>
</section>

<div class="container">
  <!-- Keresés és szűrés -->
  <div class="search-card">
    <div class="search-card__title">🔎 Termékkeresés és szűrés</div>
    <form class="search-card__form" method="get" action="index.php">
      <div class="search-card__input-wrapper">
        <span>🔍</span>
        <input type="search" name="q" value="<?= h($q) ?>" placeholder="Terméknév, leírás vagy cikkszám...">
      </div>
      <div class="search-card__input-wrapper">
        <span>🧭</span>
        <select name="kat">
          <option value="0">Minden kategória</option>
          <?php foreach($kats as $row): ?>
            <option value="<?= (int)$row['id'] ?>" <?= $kat==$row['id'] ? 'selected' : '' ?>>
              <?= h($row['nev']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <button class="btn btn-primary" type="submit">Szűrés</button>
    </form>
    <div class="search-card__result-count"><?= (int)$total ?> termék találat</div>
  </div>

  <!-- Termékkártyák -->
  <div class="grid">
    <?php foreach($products as $p): ?>
      <article class="product-card">
        <div class="product-card__image-wrapper">
          <?php if (!empty($p['kep_url'])): ?>
            <img src="<?= h($p['kep_url']) ?>" alt="<?= h($p['nev']) ?>" class="product-card__image" loading="lazy">
          <?php else: ?>
            <div class="product-card__placeholder">Nincs kép</div>
          <?php endif; ?>
        </div>

        <div class="product-card__body">
          <span class="product-card__category"><?= h($p['kategoria'] ?? 'Egyéb') ?></span>
          <h3 class="product-card__title"><?= h($p['nev']) ?></h3>
          <p class="product-card__description"><?= h(mb_substr($p['leiras'] ?? '', 0, 80)) ?></p>

          <div class="product-card__footer">
            <div class="product-card__price">
              <strong><?= number_format((float)$p['egysegar'], 0, '', ' ') ?> Ft</strong>
              <span class="badge badge-success">Készleten</span>
            </div>
          </div>

          <div class="product-card__actions">
            <a href="/raktar_pro/termek.php?id=<?= (int)$p['id'] ?>" class="btn btn-outline btn-sm">
              Részletek
            </a>

            <form method="post" action="/raktar_pro/add_to_cart.php" class="add-to-cart-form">
              <input type="hidden" name="termek_id" value="<?= (int)$p['id'] ?>">
              <input type="hidden" name="qty" value="1">
              <button class="btn btn-primary btn-sm" type="submit">
                🛒 Kosárba
              </button>
            </form>
          </div>
        </div>
      </article>
    <?php endforeach; ?>

    <?php if(empty($products)): ?>
      <p style="grid-column:1/-1;text-align:center;color:var(--color-muted);">
        Nincs találat a megadott feltételekre.
      </p>
    <?php endif; ?>
  </div>

  <!-- Lapozás -->
  <?php if($pages > 1): ?>
    <div class="pager">
      <?php for($i=1; $i<=$pages; $i++):
        $qs = http_build_query(['q'=>$q, 'kat'=>$kat, 'page'=>$i]);
      ?>
        <a class="<?= $i==$page ? 'active' : '' ?>" href="index.php?<?= $qs ?>">
          <?= $i ?>
        </a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
</div>



<!-- Scripts -->
<script src="/raktar_pro/assets/theme.js"></script>
<script src="/raktar_pro/assets/js/toast.js"></script>
<script src="/raktar_pro/assets/cart-fab.js"></script>

<script>
// Kosárba tétel feedback (stabil: JSON parse + always reset)
document.querySelectorAll('.add-to-cart-form').forEach(form => {
  form.addEventListener('submit', async function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    const button = this.querySelector('button');
    const originalText = button.innerHTML;

    // Loading state
    button.disabled = true;
    button.classList.add('loading');

    try {
      const response = await fetch('/raktar_pro/add_to_cart.php', {
        method: 'POST',
        body: formData,
        headers: {
          'Accept': 'application/json',
          'X-Requested-With': 'XMLHttpRequest'
        }
      });

      const data = await response.json().catch(() => null);

      if (!response.ok || !data || data.success !== true) {
        const msg = (data && (data.error || data.message)) ? (data.error || data.message) : 'Hiba történt';
        throw new Error(msg);
      }

      window.toast?.success?.('Termék hozzáadva a kosárhoz! 🛒');

      window.dispatchEvent(new CustomEvent('cart:add', { detail: data.cart || null }));

      const badge = document.querySelector('.navbar__cart .badge');
      if (badge && data.cart && typeof data.cart.count === 'number') {
        badge.textContent = data.cart.count;
        badge.style.display = data.cart.count > 0 ? 'inline-flex' : 'none';
      }

      button.innerHTML = '✓ Hozzáadva';

      setTimeout(() => {
        button.innerHTML = originalText;
        button.disabled = false;
      }, 1200);

    } catch (error) {
      window.toast?.error?.(error.message || 'Hiba történt a kosárba helyezéskor');
      button.innerHTML = originalText;
      button.disabled = false;

    } finally {
      button.classList.remove('loading');
    }
  });
});

// Navbar scroll effect
let lastScroll = 0;
const navbar = document.querySelector('.navbar');

window.addEventListener('scroll', () => {
  const currentScroll = window.pageYOffset;

  if (currentScroll > 50) navbar.classList.add('scrolled');
  else navbar.classList.remove('scrolled');

  lastScroll = currentScroll;
});
</script>

</body>
</html>
