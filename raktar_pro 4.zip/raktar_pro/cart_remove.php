<?php
session_start();

// ha nincs kosár, nincs mit törölni
if (!isset($_SESSION['cart'])) {
    header('Location: kosar.php');
    exit;
}

// termék ID GET-ből
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0 && isset($_SESSION['cart'][$id])) {
    unset($_SESSION['cart'][$id]);
}

// opcionális: ha kiürült, töröljük a kosarat
if (empty($_SESSION['cart'])) {
    unset($_SESSION['cart']);
}

// visszairányítás a kosár oldalra
header('Location: kosar.php');
exit;
