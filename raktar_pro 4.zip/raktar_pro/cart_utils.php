<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

function cart_init() {
  if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    $_SESSION['cart'] = []; // termek_id => qty
  }
}

function cart_add(int $termek_id, int $qty = 1) {
  cart_init();
  $qty = max(1, (int)$qty);
  $_SESSION['cart'][$termek_id] = max(1, (int)($_SESSION['cart'][$termek_id] ?? 0) + $qty);
}

function cart_set(int $termek_id, int $qty) {
  cart_init();
  $qty = (int)$qty;
  if ($qty <= 0) { unset($_SESSION['cart'][$termek_id]); return; }
  $_SESSION['cart'][$termek_id] = min($qty, 9999);
}

function cart_remove(int $termek_id) {
  cart_init();
  unset($_SESSION['cart'][$termek_id]);
}

/**
 * Kosár teljes kiürítése.
 * - Alapból: üres tömb (megtartja a session kulcsot)
 * - $hard = true: teljesen törli a $_SESSION['cart'] kulcsot is
 */
function cart_clear(bool $hard = false) {
  cart_init();
  if ($hard) {
    unset($_SESSION['cart']);
  } else {
    $_SESSION['cart'] = [];
  }
}

/**
 * Kosár tételek a VALÓS (stock tábla) készlet alapján.
 * - available = SUM(quantity - reserved_quantity) (összes lokáció)
 * - ha available <= 0: automatikus eltávolítás a kosárból
 * - ha qty > available: automatikus csökkentés available-ra
 */
function cart_items(mysqli $db): array {
  cart_init();
  if (empty($_SESSION['cart'])) return [];

  $ids = array_map('intval', array_keys($_SESSION['cart']));
  if (!$ids) return [];

  $in  = implode(',', array_fill(0, count($ids), '?'));
  $types = str_repeat('i', count($ids));

  // Products + valós készlet (stock)
  $sql = "
    SELECT
      p.id,
      p.name AS nev,
      p.sku AS cikkszam,
      p.unit_price AS egysegar,
      p.image_url AS kep_url,
      GREATEST(COALESCE(SUM(s.quantity - s.reserved_quantity), 0), 0) AS available
    FROM products p
    LEFT JOIN stock s ON s.product_id = p.id
    WHERE p.id IN ($in)
    GROUP BY p.id, p.name, p.sku, p.unit_price, p.image_url
  ";

  $stmt = $db->prepare($sql);
  if (!$stmt) return [];

  $stmt->bind_param($types, ...$ids);
  $stmt->execute();
  $res = $stmt->get_result();

  $rows = [];
  $seen = [];

  while ($r = $res->fetch_assoc()) {
    $pid = (int)$r['id'];
    $seen[$pid] = true;

    $want = (int)($_SESSION['cart'][$pid] ?? 0);
    if ($want <= 0) continue;

    $available = (int)($r['available'] ?? 0);

    // ha nincs készleten, szedjük ki a kosárból
    if ($available <= 0) {
      unset($_SESSION['cart'][$pid]);
      continue;
    }

    // ha több van a kosárban, mint elérhető, vágjuk vissza
    if ($want > $available) {
      $want = $available;
      $_SESSION['cart'][$pid] = $want;
    }

    $r['qty'] = $want;
    $r['available'] = $available;
    $r['subtotal'] = (int)$r['egysegar'] * $want;
    $rows[] = $r;
  }

  $stmt->close();

  // ha a kosárban van olyan id, ami már nincs is a products táblában -> töröljük
  foreach ($ids as $pid) {
    if (empty($seen[$pid])) unset($_SESSION['cart'][$pid]);
  }

  usort($rows, fn($a,$b)=> (int)$a['id'] <=> (int)$b['id']);
  return $rows;
}

function cart_total(mysqli $db): int {
  $items = cart_items($db);
  return (int)array_sum(array_column($items, 'subtotal'));
}

function cart_count(): int {
  cart_init();
  return (int)array_sum($_SESSION['cart']);
}
